// bypass.js
// Tiêm trực tiếp vào môi trường thực thi của trang (MAIN world)

(function () {
  // Công tắc bật/tắt runtime qua postMessage từ content script.
  // Mặc định BẬT để giữ hành vi cũ (tương thích ngược).
  // MAIN world có thể không có chrome API → đọc storage trong try/catch.
  let bypassEnabled = true;
  try {
    if (typeof chrome !== 'undefined' && chrome.storage?.local) {
      chrome.storage.local.get('stealthUIEnabled', (r) => {
        if (r && typeof r.stealthUIEnabled === 'boolean') setEnabled(r.stealthUIEnabled);
      });
    }
  } catch (_) { /* giữ default bật */ }

  window.addEventListener('message', (e) => {
    const d = e.data;
    if (d && d.source === 'lms-ai-assistant' && d.type === 'BYPASS_TOGGLE') {
      setEnabled(d.enabled !== false);
    }
  });

  function setEnabled(on) {
    bypassEnabled = on === true;
  }

  console.log('[LMS AI Assistant] Bypass Anti-Tracking module... (enabled=' + bypassEnabled + ')');

  // --- 1. Ghi đè thuộc tính Document Visibility ---
  Object.defineProperty(document, 'visibilityState', {
    get: function () {
      return 'visible';
    },
    configurable: true
  });

  Object.defineProperty(document, 'hidden', {
    get: function () {
      return false;
    },
    configurable: true
  });

  // --- 2. Ghi đè phương thức Document hasFocus ---
  Document.prototype.hasFocus = function () {
    return true;
  };

  // --- 3. Cơ chế Bypass Thông Minh (Smart Filter) ---
  
  // Các sự kiện luôn luôn bị chặn (vì nó ảnh hưởng toàn cục)
  const globalEvents = [
    'visibilitychange', 'webkitvisibilitychange', 
    'resize', 'fullscreenchange', 'selectionchange'
  ];

  // Các sự kiện chỉ chặn khi xảy ra trên tổng thể trang (Window/Document/Body). 
  // NẾU xảy ra trên 1 phần tử (VD: ô input, button), SẼ CHO PHÉP chạy bình thường!
  const windowDocOnlyEvents = [
    'blur', 'focus', 'focusout', 'focusin', 
    'mouseleave', 'mouseenter', 
    'copy', 'paste', 'cut', 'contextmenu'
  ];

  const allEvents = [...globalEvents, ...windowDocOnlyEvents];

  // 3.1. Ghi đè addEventListener để không cho phép web gắn tracking
  const originalAddEventListener = EventTarget.prototype.addEventListener;
  EventTarget.prototype.addEventListener = function (type, listener, options) {
    if (bypassEnabled && globalEvents.includes(type)) return; // Bỏ qua không đăng ký

    if (bypassEnabled && windowDocOnlyEvents.includes(type)) {
      // Chỉ chặn không cho gắn tracking nếu đối tượng là Window hoặc Document
      if (this === window || this === document) {
        return; 
      }
    }
    // Cho phép gắn sự kiện bình thường đối với các element khác
    return originalAddEventListener.call(this, type, listener, options);
  };

  // 3.2. Chặn các sự kiện bắn ra ở giai đoạn sớm nhất (Capture Phase)
  allEvents.forEach(eventType => {
    const handler = function (e) {
      if (!bypassEnabled) return;
      if (globalEvents.includes(eventType)) {
        e.stopImmediatePropagation();
      } else if (windowDocOnlyEvents.includes(eventType)) {
        // Chỉ chặn tín hiệu nếu nó xuất phát từ Window, Document hoặc Body
        if (e.target === window || e.target === document || e.target === document.documentElement || e.target === document.body) {
          e.stopImmediatePropagation();
        }
      }
    };
    
    // Gắn "khiên" bảo vệ vào Window và Document
    window.addEventListener(eventType, handler, true);
    document.addEventListener(eventType, handler, true);
  });

  // 3.3. Chặn cách gắn hàm trực tiếp kiểu window.onblur = ...
  const blockInlineEvents = () => {
      if (!bypassEnabled || document.hidden) return; // Tắt → không làm gì; tab ẩn → bỏ qua
      let found = false;
      allEvents.forEach(evt => {
          const propName = 'on' + evt;
          if (window[propName]) { window[propName] = null; found = true; }
          if (document[propName]) { document[propName] = null; found = true; }
          if (document.body && document.body[propName]) { document.body[propName] = null; found = true; }
      });
      return found;
  };

  // Chạy lúc đầu và đảm bảo chạy định kỳ trong trường hợp trang cố gắng gắn lại
  blockInlineEvents();
  setInterval(blockInlineEvents, 1000);

  console.log('[LMS AI Assistant] Bypass module đã kích hoạt.');
})();
