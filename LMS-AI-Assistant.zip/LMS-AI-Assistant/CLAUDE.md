# CLAUDE.md

Tài liệu này giúp AI agent hiểu nhanh project `LMS-AI-Assistant` trước khi sửa code.

## 1) Project là gì?

- Đây là **Chrome Extension (Manifest V3)** hỗ trợ giải bài tập LMS/Portal bằng AI.
- Agent chính:
  - `content.js`: chạy trên trang LMS, đọc câu hỏi + inject UI + hiển thị kết quả.
  - `background.js`: xử lý logic nền (API call, cache, routing, storage bridge).
  - `popup.html` + `popup.js`: giao diện cấu hình provider/model/API key và tùy chọn.
  - `style.css`: style chung cho UI popup/overlay.
  - `manifest.json`: quyền, content script, background service worker.

## 2) Kiến trúc & luồng xử lý

Luồng cơ bản khi user bấm "Ask" trên trang LMS:

1. `content.js` lấy dữ liệu câu hỏi từ DOM.
2. `content.js` gửi message sang `background.js` (`chrome.runtime.sendMessage`).
3. `background.js`:
   - đọc config hiện tại từ `chrome.storage` (endpoint/standard/provider/model/options),
   - kiểm tra cache nếu có (cache key v2: model + endpoint + standard + nội dung câu),
   - gọi API AI theo chuẩn đã resolve (OpenAI-compatible `/chat/completions` hoặc Anthropic native `/messages`),
   - trả kết quả + usage token về content script.
4. `content.js` render đáp án + giải thích + dòng token ngay dưới câu hỏi.

Dual-standard (v1.3.0+):
- Storage keys mới: `apiBaseUrl` (default `http://localhost:20128/v1`), `apiStandard` (`auto|openai|anthropic`, default `auto`). Keys cũ giữ nguyên.
- Auto-detect theo URL, không theo tên model. Chọn tay luôn thắng. Không fallback chéo chuẩn trong luồng ask thật.
- Message mới: `TEST_CONNECTION` (popup → background probe endpoint, chỉ Test mới được thử cả 2 chuẩn).
- Stats entry mở rộng: `{model, host, standard, questionType, cached, confidence, inTokens, outTokens, ts}`.
- Endpoint lạ cần `optional_host_permissions` — xin qua `chrome.permissions.request()` từ click Save/Test.

Các tính năng phụ:

- **Ask-all**: quét nhiều câu và gọi theo batch/tuần tự.
- **Floating chat**: hộp chat nổi trên trang LMS.
- **Rich render**: hỗ trợ Markdown/LaTeX (thư mục `katex/`).

## 3) Quy ước sửa code (rất quan trọng)

- Ưu tiên sửa **đúng file trách nhiệm**:
  - DOM/UI LMS -> `content.js`
  - API/caching/provider logic -> `background.js`
  - settings/control UI -> `popup.js` / `popup.html`
- Không đổi tên key trong `chrome.storage` nếu không có migration rõ ràng.
- Không hard-code API key/token trong source.
- Giữ tương thích ngược cho dữ liệu config cũ trong storage.
- Tránh refactor lớn không cần thiết; patch nhỏ, đúng vùng lỗi.

## 4) Lưu ý đặc thù Chrome Extension MV3

- `background.js` chạy dưới dạng **service worker** (không giả định state in-memory tồn tại lâu).
- Mọi thao tác dài cần an toàn với việc worker bị suspend/resume.
- Dùng message passing rõ ràng, payload tối giản.
- Kiểm tra permission trong `manifest.json` trước khi thêm tính năng mới.

## 5) Checklist trước khi kết luận đã xong

1. Reload extension trong `chrome://extensions`.
2. Mở trang LMS có câu hỏi mẫu.
3. Test tối thiểu:
   - Ask 1 câu trắc nghiệm,
   - Ask 1 câu fill-in,
   - Ask-all,
   - mở popup đổi model/provider rồi ask lại,
   - Test kết nối endpoint lạ (auto-detect chuẩn, xin quyền host),
   - đổi model rồi hỏi lại câu cũ → phải miss cache (không dính cache cũ),
   - kiểm tra bảng token theo model ở tab Thống kê + export JSON.
4. Kiểm tra lỗi trong DevTools:
   - Console của trang (content script),
   - Service Worker console (background),
   - Popup console.

## 6) Khi thêm tính năng mới

- Cập nhật `README.md` nếu thay đổi behavior người dùng nhìn thấy.
- Nếu thêm option mới trong popup:
  - thêm UI control,
  - thêm load/save trong `popup.js`,
  - thêm default handling phía `background.js`/`content.js`.

## 7) Debug nhanh

- Không thấy nút trên LMS -> kiểm tra selector/observer trong `content.js`.
- Có UI nhưng không có kết quả -> kiểm tra message action + listener giữa `content.js` và `background.js`.
- API lỗi ngẫu nhiên -> kiểm tra timeout/retry/cache key/provider mapping trong `background.js`.
- Đổi setting không ăn -> kiểm tra key storage và thời điểm đọc config.

---

Nếu bạn là agent mới vào project: đọc file này trước, sau đó mở `manifest.json`, `content.js`, `background.js` để nắm nhanh toàn bộ luồng chính.

