// =====================================================
// Defaults dùng chung với background.js (giữ đồng bộ tay — MV3 popup/SW
// không share module). Keys cũ giữ nguyên, chỉ thêm apiBaseUrl/apiStandard.
// =====================================================
const DEFAULT_BASE_URL = 'http://localhost:20128/v1';
const DEFAULT_STANDARD = 'auto';

// =====================================================
// Khởi tạo popup
// =====================================================
document.addEventListener('DOMContentLoaded', () => {
  // ── Element refs ──
  const modelNameInput = document.getElementById('modelNameInput');
  const detectedModelsArea = document.getElementById('detectedModelsArea');
  const detectedModelsSelect = document.getElementById('detectedModelsSelect');
  const detectedModelCount = document.getElementById('detectedModelCount');
  const detectedModelsList = document.getElementById('detectedModelsList');
  const dualModelToggle = document.getElementById('dualModelToggle');
  const model2Area = document.getElementById('model2Area');
  const apiBaseUrl2Input = document.getElementById('apiBaseUrl2');
  const apiStandard2Select = document.getElementById('apiStandard2');
  const apiKey2Input = document.getElementById('apiKey2');
  const toggleKey2Btn = document.getElementById('toggleKey2Btn');
  const testBtn2 = document.getElementById('testBtn2');
  const testStatus2El = document.getElementById('testStatus2');
  const detectedModels2Select = document.getElementById('detectedModels2Select');
  const detectedModels2List = document.getElementById('detectedModels2List');
  const model2NameInput = document.getElementById('model2NameInput');
  const openTabBtn = document.getElementById('openTabBtn');

  const apiBaseUrlInput = document.getElementById('apiBaseUrl');
  const apiStandardSelect = document.getElementById('apiStandard');
  const apiKeyInput = document.getElementById('apiKey');
  const toggleKeyBtn = document.getElementById('toggleKeyBtn');
  const testBtn = document.getElementById('testBtn');
  const testStatusEl = document.getElementById('testStatus');
  const saveBtn = document.getElementById('saveBtn');
  const statusEl = document.getElementById('status');
  const enabledToggle = document.getElementById('enabledToggle');
  const powerLabel = document.getElementById('powerLabel');
  const settingsArea = document.getElementById('settingsArea');
  const richFormatToggle = document.getElementById('richFormatToggle');
  const autoFillToggle = document.getElementById('autoFillToggle');
  const stealthUIToggle = document.getElementById('stealthUIToggle');
  const microDotToggle = document.getElementById('microDotToggle');
  const pacingDelaySelect = document.getElementById('pacingDelaySelect');
  const clearCacheBtn = document.getElementById('clearCacheBtn');
  const cacheStatusEl = document.getElementById('cacheStatus');
  const exportStatsBtn = document.getElementById('exportStatsBtn');
  const clearStatsBtn = document.getElementById('clearStatsBtn');
  const statsStatusEl = document.getElementById('statsStatus');
  const statusDot = document.getElementById('statusDot');
  const statusText = document.getElementById('statusText');
  const statusModel = document.getElementById('statusModel');
  const statusToday = document.getElementById('statusToday');

  // ── Nút mở popup trong tab riêng (không bị đóng khi chuyển tab copy text) ──
  if (openTabBtn) {
    if (window.innerWidth > 500 || window.location.search.includes('mode=tab')) {
      openTabBtn.style.display = 'none';
    } else {
      openTabBtn.addEventListener('click', () => {
        chrome.tabs.create({ url: chrome.runtime.getURL('popup.html?mode=tab') });
      });
    }
  }

  // ── Tab switching ──
  document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(btn.dataset.tab).classList.add('active');
      if (btn.dataset.tab === 'panelStats') loadStats();
    });
  });

  // ── Render danh sách model bắt được từ endpoint Model 2 ──
  function updateDetectedModels2UI(models, currentModel2) {
    if (!detectedModels2Select) return;
    if (!Array.isArray(models) || models.length === 0) {
      detectedModels2Select.style.display = 'none';
      detectedModels2Select.innerHTML = '<option value="">-- Chọn model 2 từ endpoint --</option>';
      if (detectedModels2List) detectedModels2List.innerHTML = '';
      return;
    }

    detectedModels2Select.style.display = 'block';
    detectedModels2Select.innerHTML = `<option value="">-- Chọn model 2 (${models.length} model) --</option>`;
    models.forEach(m => {
      const opt = document.createElement('option');
      opt.value = m;
      opt.textContent = m;
      if (m === currentModel2) opt.selected = true;
      detectedModels2Select.appendChild(opt);
    });

    if (detectedModels2List) {
      detectedModels2List.innerHTML = '';
      models.forEach(m => {
        const dataOpt = document.createElement('option');
        dataOpt.value = m;
        detectedModels2List.appendChild(dataOpt);
      });
    }
  }

  // ── Render danh sách model bắt được từ endpoint Model 1 ──
  function updateDetectedModelsUI(models, currentModel, currentModel2) {
    if (!Array.isArray(models) || models.length === 0) {
      if (detectedModelsArea) detectedModelsArea.style.display = 'none';
      if (detectedModelsSelect) detectedModelsSelect.innerHTML = '<option value="">-- Chọn model để điền --</option>';
      if (detectedModelsList) detectedModelsList.innerHTML = '';
      return;
    }

    if (detectedModelsArea) detectedModelsArea.style.display = 'block';
    if (detectedModelCount) detectedModelCount.textContent = models.length;

    if (detectedModelsSelect) {
      detectedModelsSelect.innerHTML = `<option value="">-- Chọn model từ endpoint (${models.length} model) --</option>`;
      models.forEach(m => {
        const opt = document.createElement('option');
        opt.value = m;
        opt.textContent = m;
        if (m === currentModel) opt.selected = true;
        detectedModelsSelect.appendChild(opt);
      });
    }

    // Nếu Model 2 không dùng endpoint riêng, chia sẻ danh sách model này cho Model 2
    if (apiBaseUrl2Input && !apiBaseUrl2Input.value.trim()) {
      updateDetectedModels2UI(models, currentModel2);
    }

    if (detectedModelsList) {
      detectedModelsList.innerHTML = '';
      models.forEach(m => {
        const dataOpt = document.createElement('option');
        dataOpt.value = m;
        detectedModelsList.appendChild(dataOpt);
      });
    }
  }

  // Khi người dùng chọn model từ danh sách endpoint
  if (detectedModelsSelect) {
    detectedModelsSelect.addEventListener('change', () => {
      const selected = detectedModelsSelect.value;
      if (selected) {
        modelNameInput.value = selected;
        updateStatusModel(selected);
        autoSaveConfig();
      }
    });
  }

  // Khi người dùng chọn model 2 từ danh sách endpoint
  if (detectedModels2Select) {
    detectedModels2Select.addEventListener('change', () => {
      const selected = detectedModels2Select.value;
      if (selected) {
        model2NameInput.value = selected;
        autoSaveConfig();
      }
    });
  }

  // Bật/tắt chế độ Dual-Model
  if (dualModelToggle) {
    dualModelToggle.addEventListener('change', () => {
      const isDual = dualModelToggle.checked;
      if (model2Area) model2Area.style.display = isDual ? 'block' : 'none';
      autoSaveConfig();
    });
  }

  // Khi người dùng gõ trực tiếp tên model 2
  if (model2NameInput) {
    model2NameInput.addEventListener('input', () => {
      const val = model2NameInput.value.trim();
      if (detectedModels2Select) {
        let matched = false;
        for (const opt of detectedModels2Select.options) {
          if (opt.value && opt.value === val) {
            detectedModels2Select.value = val;
            matched = true;
            break;
          }
        }
        if (!matched) detectedModels2Select.value = '';
      }
      debouncedSave();
    });
  }

  // Khi người dùng gõ trực tiếp tên model
  if (modelNameInput) {
    modelNameInput.addEventListener('input', () => {
      const val = modelNameInput.value.trim();
      updateStatusModel(val);

      if (detectedModelsSelect) {
        let matched = false;
        for (const opt of detectedModelsSelect.options) {
          if (opt.value && opt.value === val) {
            detectedModelsSelect.value = val;
            matched = true;
            break;
          }
        }
        if (!matched) detectedModelsSelect.value = '';
      }

      debouncedSave();
    });
  }

  function updateStatusModel(name) {
    statusModel.textContent = name || '—';
    statusModel.title = name || '—';
  }

  // ── Tự động lưu nháp (Auto-save) để khi chuyển tab không bị mất dữ liệu ──
  let saveTimer = null;
  function debouncedSave() {
    clearTimeout(saveTimer);
    saveTimer = setTimeout(autoSaveConfig, 300);
  }

  function autoSaveConfig() {
    const siteMode = document.querySelector('input[name="siteMode"]:checked')?.value || 'portal';
    const modelName = modelNameInput ? modelNameInput.value.trim() : '';
    const dualModelEnabled = dualModelToggle ? dualModelToggle.checked : false;
    const model2Name = model2NameInput ? model2NameInput.value.trim() : '';
    const apiKey = apiKeyInput ? apiKeyInput.value.trim() : '';
    const apiStandard = apiStandardSelect ? apiStandardSelect.value : DEFAULT_STANDARD;
    const apiBaseUrl = apiBaseUrlInput ? apiBaseUrlInput.value.trim() : DEFAULT_BASE_URL;

    const apiBaseUrl2 = apiBaseUrl2Input ? apiBaseUrl2Input.value.trim() : '';
    const apiStandard2 = apiStandard2Select ? apiStandard2Select.value : 'auto';
    const apiKey2 = apiKey2Input ? apiKey2Input.value.trim() : '';

    chrome.storage.local.set({
      siteMode,
      modelName,
      dualModelEnabled,
      model2Name,
      apiKey,
      apiStandard,
      apiBaseUrl,
      apiBaseUrl2,
      apiStandard2,
      apiKey2,
      providerId: 'custom'
    });
  }

  apiBaseUrlInput.addEventListener('input', debouncedSave);
  apiStandardSelect.addEventListener('change', autoSaveConfig);
  apiKeyInput.addEventListener('input', debouncedSave);

  if (apiBaseUrl2Input) apiBaseUrl2Input.addEventListener('input', debouncedSave);
  if (apiStandard2Select) apiStandard2Select.addEventListener('change', autoSaveConfig);
  if (apiKey2Input) apiKey2Input.addEventListener('input', debouncedSave);

  document.querySelectorAll('input[name="siteMode"]').forEach(radio => {
    radio.addEventListener('change', () => {
      autoSaveConfig();
      const siteMode = radio.value;
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]?.id) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'SITE_MODE_CHANGED', siteMode });
        }
      });
    });
  });

  // Lưu tức thì khi cửa sổ popup bị mất focus hoặc đóng lại
  window.addEventListener('beforeunload', autoSaveConfig);
  window.addEventListener('pagehide', autoSaveConfig);
  window.addEventListener('blur', autoSaveConfig);

  // ── Load saved settings ──
  chrome.storage.local.get(
    ['modelName', 'model2Name', 'dualModelEnabled', 'apiKey', 'siteMode', 'extensionEnabled', 'richFormat', 'autoFillEnabled', 'stealthUIEnabled', 'microDotMode', 'pacingDelay', 'apiBaseUrl', 'apiStandard', 'apiBaseUrl2', 'apiStandard2', 'apiKey2', 'lastTestOk', 'lastTestMessage', 'lastTest2Ok', 'lastTest2Message', 'detectedModels', 'detectedModels2', 'stats'],
    (result) => {
      // Extension toggle
      const isEnabled = result.extensionEnabled !== false;
      applyEnabledState(isEnabled);

      // Site mode: loại bỏ mode LMS HUST cũ, chỉ dùng portal hoặc vnu
      let savedMode = result.siteMode;
      if (savedMode === 'lms') savedMode = 'portal';
      if (savedMode) {
        const modeRadio = document.querySelector(`input[name="siteMode"][value="${savedMode}"]`);
        if (modeRadio) modeRadio.checked = true;
      } else {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          const url = tabs[0]?.url || '';
          let m = 'portal';
          if (url.includes('lms.vnu.edu.vn')) m = 'vnu';
          const modeRadio = document.querySelector(`input[name="siteMode"][value="${m}"]`);
          if (modeRadio) {
            modeRadio.checked = true;
            autoSaveConfig();
          }
        });
      }

      // Endpoint + chuẩn API
      apiBaseUrlInput.value = result.apiBaseUrl ?? DEFAULT_BASE_URL;
      apiStandardSelect.value = result.apiStandard ?? DEFAULT_STANDARD;
      apiKeyInput.value = result.apiKey || '';

      // Tên Model
      const savedModel = result.modelName || '';
      modelNameInput.value = savedModel;
      updateStatusModel(savedModel);

      // Model 2 & Dual-Model
      const isDual = result.dualModelEnabled === true;
      if (dualModelToggle) dualModelToggle.checked = isDual;
      if (model2Area) model2Area.style.display = isDual ? 'block' : 'none';
      if (model2NameInput) model2NameInput.value = result.model2Name || '';
      if (apiBaseUrl2Input) apiBaseUrl2Input.value = result.apiBaseUrl2 || '';
      if (apiStandard2Select) apiStandard2Select.value = result.apiStandard2 || 'auto';
      if (apiKey2Input) apiKey2Input.value = result.apiKey2 || '';

      if (result.lastTest2Message && testStatus2El) {
        setTestStatus2(result.lastTest2Message, result.lastTest2Ok === false);
      }

      // Khôi phục các model nhận diện được từ endpoint Model 1
      if (Array.isArray(result.detectedModels) && result.detectedModels.length > 0) {
        updateDetectedModelsUI(result.detectedModels, savedModel, result.model2Name || '');
      }

      // Khôi phục các model nhận diện được từ endpoint Model 2
      if (Array.isArray(result.detectedModels2) && result.detectedModels2.length > 0) {
        updateDetectedModels2UI(result.detectedModels2, result.model2Name || '');
      } else if (Array.isArray(result.detectedModels) && result.detectedModels.length > 0 && !result.apiBaseUrl2) {
        updateDetectedModels2UI(result.detectedModels, result.model2Name || '');
      }

      // Khôi phục trạng thái test gần nhất
      if (result.lastTestMessage) {
        setTestStatus(result.lastTestMessage, result.lastTestOk === false);
      }

      // Toggles
      richFormatToggle.checked = result.richFormat === true;
      autoFillToggle.checked = result.autoFillEnabled !== false; // Mặc định bật
      stealthUIToggle.checked = result.stealthUIEnabled === true; // Mặc định tắt
      microDotToggle.checked = result.microDotMode === true; // Mặc định tắt
      pacingDelaySelect.value = result.pacingDelay || 'normal';

      // Status card thật
      renderStatusCard(result);
    }
  );

  /** Card trạng thái: kết quả test gần nhất + model + requests/tokens hôm nay. */
  function renderStatusCard(result) {
    const model = result.modelName || '—';
    updateStatusModel(model);

    const stats = Array.isArray(result.stats) ? result.stats : [];
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);
    const today = stats.filter(s => (s.ts || 0) >= startOfDay.getTime());
    const tokens = today.reduce((sum, s) => sum + (s.inTokens || 0) + (s.outTokens || 0), 0);
    statusToday.textContent = `${today.length} requests · ${formatNum(tokens)} tokens`;

    if (result.lastTestOk === true) {
      statusDot.className = 'status-dot ok';
      statusText.textContent = 'Kết nối OK (lần test gần nhất)';
    } else if (result.lastTestOk === false) {
      statusDot.className = 'status-dot err';
      statusText.textContent = 'Kết nối lỗi (lần test gần nhất)';
    } else {
      statusDot.className = 'status-dot';
      statusText.textContent = 'Chưa kiểm tra kết nối';
    }
  }

  function formatNum(n) {
    return Number(n || 0).toLocaleString('en-US');
  }

  // ── Power toggle ──
  enabledToggle.addEventListener('change', () => {
    const enabled = enabledToggle.checked;
    applyEnabledState(enabled);
    chrome.storage.local.set({ extensionEnabled: enabled }, () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]?.id) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'EXTENSION_TOGGLE', enabled });
        }
      });
    });
  });

  function applyEnabledState(enabled) {
    enabledToggle.checked = enabled;
    powerLabel.textContent = enabled ? 'ON' : 'OFF';
    powerLabel.className = 'power-label ' + (enabled ? 'on' : 'off');
    document.body.classList.toggle('disabled-mode', !enabled);
    settingsArea.classList.toggle('dimmed', !enabled);
  }

  // ── Rich format toggle ──
  richFormatToggle.addEventListener('change', () => {
    const isRich = richFormatToggle.checked;
    chrome.storage.local.set({ richFormat: isRich }, () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]?.id) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'RICH_FORMAT_CHANGED', richFormat: isRich });
        }
      });
    });
  });

  // ── Auto Fill toggle ──
  autoFillToggle.addEventListener('change', () => {
    const isAutoFill = autoFillToggle.checked;
    chrome.storage.local.set({ autoFillEnabled: isAutoFill }, () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]?.id) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'AUTOFILL_CHANGED', autoFillEnabled: isAutoFill });
        }
      });
    });
  });

  // ── Stealth UI toggle ──
  stealthUIToggle.addEventListener('change', () => {
    const isStealth = stealthUIToggle.checked;
    chrome.storage.local.set({ stealthUIEnabled: isStealth }, () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]?.id) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'STEALTH_UI_CHANGED', stealthUIEnabled: isStealth });
        }
      });
    });
  });

  // ── Micro Dot toggle ──
  microDotToggle.addEventListener('change', () => {
    const isMicro = microDotToggle.checked;
    chrome.storage.local.set({ microDotMode: isMicro }, () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]?.id) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'MICRO_DOT_CHANGED', microDotMode: isMicro });
        }
      });
    });
  });

  // ── Pacing Delay select ──
  pacingDelaySelect.addEventListener('change', () => {
    const val = pacingDelaySelect.value;
    chrome.storage.local.set({ pacingDelay: val }, () => {
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]?.id) {
          chrome.tabs.sendMessage(tabs[0].id, { type: 'PACING_DELAY_CHANGED', pacingDelay: val });
        }
      });
    });
  });

  // ── Hiện/ẩn API key ──
  toggleKeyBtn.addEventListener('click', () => {
    const isPassword = apiKeyInput.type === 'password';
    apiKeyInput.type = isPassword ? 'text' : 'password';
    toggleKeyBtn.textContent = isPassword ? 'Ẩn' : 'Hiện';
  });

  if (toggleKey2Btn && apiKey2Input) {
    toggleKey2Btn.addEventListener('click', () => {
      const isPassword = apiKey2Input.type === 'password';
      apiKey2Input.type = isPassword ? 'text' : 'password';
      toggleKey2Btn.textContent = isPassword ? 'Ẩn' : 'Hiện';
    });
  }

  /** Validate + normalize endpoint URL. Ném Error nếu sai format. */
  function parseBaseUrl(raw) {
    let s = String(raw || '').trim().replace(/\/+$/, '') || DEFAULT_BASE_URL;
    if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(s)) {
      const isLocal = /^(localhost|127\.0\.0\.1|\[::1\])([:/]|$)/.test(s);
      s = (isLocal ? 'http://' : 'https://') + s;
    }
    let url;
    try {
      url = new URL(s);
    } catch (_) {
      throw new Error('Endpoint URL không hợp lệ. Ví dụ: api.xpiki.com/v1');
    }
    if (url.protocol !== 'http:' && url.protocol !== 'https:') {
      throw new Error('Endpoint URL phải bắt đầu bằng http:// hoặc https://');
    }
    return url.toString().replace(/\/+$/, '');
  }

  /** Xin quyền truy cập origin lạ (optional_host_permissions). */
  async function ensureHostPermission(baseUrl) {
    const origin = new URL(baseUrl).origin + '/*';
    try {
      const has = await chrome.permissions.contains({ origins: [origin] });
      if (has) return true;
      return await chrome.permissions.request({ origins: [origin] });
    } catch (err) {
      console.warn('[Popup] permissions.request lỗi:', err?.message);
      return false;
    }
  }

  // ── Save settings (lưu chính thức + xin quyền) ──
  saveBtn.addEventListener('click', async () => {
    const siteMode = document.querySelector('input[name="siteMode"]:checked')?.value || 'portal';
    const modelName = modelNameInput.value.trim();
    const apiKey = apiKeyInput.value.trim();
    const apiStandard = apiStandardSelect.value;

    let apiBaseUrl;
    try {
      apiBaseUrl = parseBaseUrl(apiBaseUrlInput.value);
    } catch (err) {
      setStatus(err.message, true);
      return;
    }

    if (!apiKey) { setStatus('Vui lòng nhập API Key / Token.', true); return; }
    if (!modelName) { setStatus('Vui lòng chọn hoặc nhập tên model.', true); return; }

    saveBtn.disabled = true;
    const oldLabel = saveBtn.textContent;
    saveBtn.textContent = 'Đang lưu...';
    try {
      const granted = await ensureHostPermission(apiBaseUrl);
      apiBaseUrlInput.value = apiBaseUrl;
      const dualModelEnabled = dualModelToggle ? dualModelToggle.checked : false;
      const model2Name = model2NameInput ? model2NameInput.value.trim() : '';
      const apiBaseUrl2Raw = apiBaseUrl2Input ? apiBaseUrl2Input.value.trim() : '';
      const apiStandard2 = apiStandard2Select ? apiStandard2Select.value : 'auto';
      const apiKey2 = apiKey2Input ? apiKey2Input.value.trim() : '';

      let apiBaseUrl2 = '';
      if (apiBaseUrl2Raw) {
        try {
          apiBaseUrl2 = parseBaseUrl(apiBaseUrl2Raw);
          apiBaseUrl2Input.value = apiBaseUrl2;
        } catch (err) {
          setStatus('Model 2: ' + err.message, true);
          return;
        }
      }

      if (dualModelEnabled && !model2Name) {
        setStatus('Bạn đang bật Dual-Model: vui lòng nhập tên cho Model 2.', true);
        return;
      }

      if (apiBaseUrl2) {
        await ensureHostPermission(apiBaseUrl2);
      }

      chrome.storage.local.set({
        siteMode,
        modelName,
        dualModelEnabled,
        model2Name,
        apiKey,
        apiBaseUrl,
        apiStandard,
        apiBaseUrl2,
        apiStandard2,
        apiKey2,
        providerId: 'custom'
      }, () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
          if (tabs[0]?.id) {
            chrome.tabs.sendMessage(tabs[0].id, { type: 'SITE_MODE_CHANGED', siteMode });
          }
        });
        if (granted) {
          setStatus('Đã lưu — trang sẽ tự cập nhật!', false);
        } else {
          setStatus('Đã lưu, nhưng endpoint chưa được cấp quyền truy cập. Bấm "Kiểm tra kết nối" để cấp quyền.', true);
        }
      });
    } finally {
      saveBtn.disabled = false;
      saveBtn.textContent = oldLabel;
    }
  });

  function setStatus(message, isError) {
    statusEl.textContent = message;
    statusEl.className = isError ? 'status-err' : 'status-ok';
  }

  function setTestStatus(html, isError) {
    testStatusEl.innerHTML = html;
    testStatusEl.className = isError ? 'status-err' : 'status-ok';
  }

  function setTestStatus2(html, isError) {
    if (!testStatus2El) return;
    testStatus2El.innerHTML = html;
    testStatus2El.className = isError ? 'status-err' : 'status-ok';
  }

  // ── Test kết nối endpoint Model 2 & tự động bắt model ──
  if (testBtn2) {
    testBtn2.addEventListener('click', async () => {
      const urlRaw = (apiBaseUrl2Input?.value.trim()) || (apiBaseUrlInput?.value.trim()) || DEFAULT_BASE_URL;
      let baseUrl2;
      try {
        baseUrl2 = parseBaseUrl(urlRaw);
      } catch (err) {
        setTestStatus2(escapeHtml(err.message), true);
        return;
      }

      const key2 = (apiKey2Input?.value.trim()) || (apiKeyInput?.value.trim());
      if (!key2) {
        setTestStatus2('Vui lòng nhập API Key cho Model 2 (hoặc Model 1).', true);
        return;
      }

      const std2 = apiStandard2Select ? apiStandard2Select.value : 'auto';
      const m2Name = model2NameInput ? model2NameInput.value.trim() : '';

      testBtn2.disabled = true;
      setTestStatus2('<span class="spinner"></span>Đang kiểm tra kết nối Model 2...', false);

      try {
        const granted = await ensureHostPermission(baseUrl2);
        if (!granted) {
          setTestStatus2('Endpoint Model 2 chưa được cấp quyền. Hãy bấm lại và chọn "Cho phép".', true);
          chrome.storage.local.set({ lastTest2Ok: false });
          return;
        }

        if (apiBaseUrl2Input?.value.trim()) {
          apiBaseUrl2Input.value = baseUrl2;
        }
        autoSaveConfig();

        const res = await chrome.runtime.sendMessage({
          type: 'TEST_CONNECTION', baseUrl: baseUrl2, apiKey: key2, standard: std2, modelName: m2Name
        });

        if (res?.ok) {
          const stdLabel = res.detectedStandard === 'anthropic' ? 'Anthropic native (/messages)' : 'OpenAI-compatible (/chat/completions)';
          let extra = '';
          if (Array.isArray(res.models) && res.models.length > 0) {
            extra = `<br/>Endpoint liệt kê ${res.models.length} model. Đã cập nhật danh sách chọn Model 2!`;
            chrome.storage.local.set({ detectedModels2: res.models });
            updateDetectedModels2UI(res.models, model2NameInput ? model2NameInput.value.trim() : '');

            // Nếu ô model 2 trống, tự chọn 1 model phù hợp
            if (model2NameInput && !model2NameInput.value.trim()) {
              const m1 = modelNameInput ? modelNameInput.value.trim() : '';
              const pick = res.models.find(m => m !== m1) || res.models[0];
              model2NameInput.value = pick;
              if (detectedModels2Select) detectedModels2Select.value = pick;
              autoSaveConfig();
            }
          } else if (std2 === 'auto') {
            extra = `<br/>Đã phát hiện chuẩn: ${escapeHtml(stdLabel)}.`;
          }

          const okMessage = `OK — ${escapeHtml(stdLabel)} · ${res.latencyMs}ms.${extra}`;
          setTestStatus2(okMessage, false);
          chrome.storage.local.set({ lastTest2Ok: true, lastTest2Message: okMessage });
        } else {
          const errMsg = `Lỗi: ${escapeHtml(res?.error || 'không rõ nguyên nhân')}`;
          setTestStatus2(errMsg, true);
          chrome.storage.local.set({ lastTest2Ok: false, lastTest2Message: errMsg });
        }
      } catch (err) {
        const errMsg = `Lỗi: ${escapeHtml(err?.message || String(err))}`;
        setTestStatus2(errMsg, true);
        chrome.storage.local.set({ lastTest2Ok: false, lastTest2Message: errMsg });
      } finally {
        testBtn2.disabled = false;
      }
    });
  }

  // ── Test kết nối endpoint & tự động bắt model ──
  testBtn.addEventListener('click', async () => {
    let apiBaseUrl;
    try {
      apiBaseUrl = parseBaseUrl(apiBaseUrlInput.value);
    } catch (err) {
      setTestStatus(escapeHtml(err.message), true);
      return;
    }
    const apiKey = apiKeyInput.value.trim();
    const apiStandard = apiStandardSelect.value;
    const modelName = modelNameInput.value.trim();
    if (!apiKey) { setTestStatus('Vui lòng nhập API Key trước khi test.', true); return; }

    testBtn.disabled = true;
    setTestStatus('<span class="spinner"></span>Đang kiểm tra kết nối...', false);
    try {
      const granted = await ensureHostPermission(apiBaseUrl);
      if (!granted) {
        setTestStatus('Endpoint chưa được cấp quyền. Hãy bấm lại và chọn "Cho phép" khi Chrome hỏi.', true);
        chrome.storage.local.set({ lastTestOk: false });
        return;
      }
      apiBaseUrlInput.value = apiBaseUrl;
      autoSaveConfig();

      const res = await chrome.runtime.sendMessage({
        type: 'TEST_CONNECTION', baseUrl: apiBaseUrl, apiKey, standard: apiStandard, modelName
      });

      if (res?.ok) {
        const stdLabel = res.detectedStandard === 'anthropic' ? 'Anthropic native (/messages)' : 'OpenAI-compatible (/chat/completions)';
        let extra = '';
        if (Array.isArray(res.models) && res.models.length > 0) {
          extra = `<br/>Endpoint liệt kê ${res.models.length} model. Đã cập nhật vào danh sách chọn bên dưới!`;
          // Lưu danh sách model vào storage để không bị mất khi đóng popup
          chrome.storage.local.set({ detectedModels: res.models });
          updateDetectedModelsUI(res.models, modelNameInput.value.trim(), model2NameInput ? model2NameInput.value.trim() : '');

          // Nếu ô model còn trống thì tự chọn model đầu tiên
          if (!modelNameInput.value.trim()) {
            modelNameInput.value = res.models[0];
            if (detectedModelsSelect) detectedModelsSelect.value = res.models[0];
            updateStatusModel(res.models[0]);
            autoSaveConfig();
          }
        } else if (apiStandard === 'auto') {
          extra = `<br/>Đã phát hiện chuẩn: ${escapeHtml(stdLabel)}.`;
        }

        const okMessage = `OK — ${escapeHtml(stdLabel)} · ${res.latencyMs}ms.${extra}`;
        setTestStatus(okMessage, false);
        chrome.storage.local.set({ lastTestOk: true, lastTestMessage: okMessage }, () =>
          chrome.storage.local.get(['modelName', 'stats'], (r) => renderStatusCard({ ...r, lastTestOk: true })));
      } else {
        const errMsg = `Lỗi: ${escapeHtml(res?.error || 'không rõ nguyên nhân')}`;
        setTestStatus(errMsg, true);
        chrome.storage.local.set({ lastTestOk: false, lastTestMessage: errMsg }, () =>
          chrome.storage.local.get(['modelName', 'stats'], (r) => renderStatusCard({ ...r, lastTestOk: false })));
      }
    } catch (err) {
      const errMsg = `Lỗi: ${escapeHtml(err?.message || String(err))}`;
      setTestStatus(errMsg, true);
      chrome.storage.local.set({ lastTestOk: false, lastTestMessage: errMsg });
    } finally {
      testBtn.disabled = false;
    }
  });

  function escapeHtml(s) {
    return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  }

  // ── Clear cache ──
  clearCacheBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ type: 'CLEAR_CACHE' }, () => {
      cacheStatusEl.textContent = 'Đã xóa cache câu hỏi!';
      cacheStatusEl.className = 'status-ok';
      setTimeout(() => { cacheStatusEl.textContent = ''; }, 3000);
      loadStats();
    });
  });

  // ── Export stats JSON ──
  exportStatsBtn.addEventListener('click', () => {
    chrome.storage.local.get('stats', ({ stats }) => {
      const data = Array.isArray(stats) ? stats : [];
      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      const day = new Date().toISOString().slice(0, 10);
      a.href = url;
      a.download = `lms-ai-stats-${day}.json`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
      statsStatusEl.textContent = `Đã xuất ${data.length} bản ghi.`;
      statsStatusEl.className = 'status-ok';
      setTimeout(() => { statsStatusEl.textContent = ''; }, 3000);
    });
  });

  // ── Clear stats (xác nhận 2 bước, không dùng confirm()) ──
  let clearStatsArmed = false;
  let clearStatsTimer = null;
  clearStatsBtn.addEventListener('click', () => {
    if (!clearStatsArmed) {
      clearStatsArmed = true;
      clearStatsBtn.textContent = 'Bấm lần nữa để xác nhận';
      statsStatusEl.textContent = 'Bấm lần nữa để xóa toàn bộ thống kê. Hành động không thể hoàn tác.';
      statsStatusEl.className = 'status-err';
      clearStatsTimer = setTimeout(() => {
        clearStatsArmed = false;
        clearStatsBtn.textContent = 'Xóa thống kê';
        statsStatusEl.textContent = '';
      }, 4000);
      return;
    }
    clearTimeout(clearStatsTimer);
    clearStatsArmed = false;
    clearStatsBtn.textContent = 'Xóa thống kê';
    chrome.storage.local.remove('stats', () => {
      statsStatusEl.textContent = 'Đã xóa thống kê.';
      statsStatusEl.className = 'status-ok';
      setTimeout(() => { statsStatusEl.textContent = ''; }, 3000);
      loadStats();
    });
  });

  // ── Load Stats ──
  function loadStats() {
    chrome.storage.local.get('stats', ({ stats }) => {
      const data = Array.isArray(stats) ? stats : [];

      const total = data.length;
      const cacheHits = data.filter(d => d.cached).length;
      const cacheHitPct = total > 0 ? Math.round((cacheHits / total) * 100) : 0;

      const withConf = data.filter(d => typeof d.confidence === 'number');
      const avgConf = withConf.length > 0
        ? Math.round((withConf.reduce((s, d) => s + d.confidence, 0) / withConf.length) * 100)
        : null;

      const fillInCount = data.filter(d => d.questionType === 'fill_in').length;

      document.getElementById('statTotal').textContent = total;
      document.getElementById('statCacheHit').textContent = cacheHitPct + '%';
      document.getElementById('statConfidence').textContent = avgConf !== null ? avgConf + '%' : '—';
      document.getElementById('statFillIn').textContent = fillInCount;

      const byModel = {};
      data.forEach(d => {
        const key = d.model || '(không rõ)';
        if (!byModel[key]) byModel[key] = { req: 0, cache: 0, inT: 0, outT: 0 };
        const row = byModel[key];
        row.req += 1;
        if (d.cached) row.cache += 1;
        row.inT += d.inTokens || 0;
        row.outT += d.outTokens || 0;
      });
      const rows = Object.entries(byModel)
        .sort((a, b) => (b[1].inT + b[1].outT) - (a[1].inT + a[1].outT));

      const table = document.getElementById('statsTable');
      const tbody = document.getElementById('statsTableBody');
      const emptyEl = document.getElementById('statsEmpty');
      tbody.innerHTML = '';
      if (rows.length === 0) {
        table.style.display = 'none';
        emptyEl.style.display = 'block';
      } else {
        emptyEl.style.display = 'none';
        table.style.display = 'table';
        rows.forEach(([model, r]) => {
          const tr = document.createElement('tr');
          const shortName = model.split('/').pop();
          tr.innerHTML =
            `<td class="model-cell"></td><td>${r.req}</td><td>${r.cache}</td>` +
            `<td>${formatNum(r.inT)}</td><td>${formatNum(r.outT)}</td><td>${formatNum(r.inT + r.outT)}</td>`;
          tr.firstChild.textContent = shortName;
          tr.firstChild.title = model;
          tbody.appendChild(tr);
        });
      }
    });
  }
});
