// ═══════════════════════════════════════════════════
// CONFIG — DUAL STANDARD (OpenAI-compatible + Anthropic)
// Keys mới: apiBaseUrl, apiStandard. Keys cũ giữ nguyên (tương thích ngược).
// ═══════════════════════════════════════════════════
const DEFAULT_BASE_URL = 'http://localhost:20128/v1';
const ANTHROPIC_VERSION = '2023-06-01';
const AI_TIMEOUT_MS = 90000; // Model reasoning chậm — 90s an toàn hơn 60s
const ANTHROPIC_MAX_TOKENS = 2048; // Anthropic bắt buộc max_tokens (thiếu → HTTP 400)

const STORAGE_DEFAULTS = {
  modelName: 'gemini/gemini-1.5-flash',
  apiBaseUrl: DEFAULT_BASE_URL,
  apiStandard: 'auto', // 'auto' | 'openai' | 'anthropic'
};

/**
 * Chuẩn hóa base URL: trim + bỏ trailing slash. Rỗng → default.
 * Tự thêm scheme khi thiếu (localhost → http, còn lại → https) để fetch
 * không lỗi nếu storage chứa giá trị scheme-less (vd: bị sửa tay).
 */
function normalizeBaseUrl(raw) {
  let s = String(raw || '').trim().replace(/\/+$/, '') || DEFAULT_BASE_URL;
  if (!/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(s)) {
    const isLocal = /^(localhost|127\.0\.0\.1|\[::1\])([:/]|$)/.test(s);
    s = (isLocal ? 'http://' : 'https://') + s;
  }
  return s;
}

/** Ghép endpoint theo chuẩn. Nếu base đã kết thúc đúng path thì giữ nguyên. */
function joinEndpoint(base, standard) {
  const path = standard === 'anthropic' ? '/messages' : '/chat/completions';
  if (base.endsWith(path)) return base;
  return base + path;
}

/**
 * Resolve chuẩn API. Chọn tay luôn thắng.
 * Auto: detect theo URL (KHÔNG theo tên model — gateway OpenAI-compatible
 * vẫn route các id claude-* nên heuristic theo model sẽ đoán sai).
 */
function resolveStandard(baseUrl, setting) {
  if (setting === 'openai' || setting === 'anthropic') return setting;
  const low = String(baseUrl || '').toLowerCase();
  if (low.includes('anthropic.com') || low.endsWith('/messages') || low.includes('/anthropic')) {
    return 'anthropic';
  }
  return 'openai';
}

/** Chỉ lấy hostname để lưu stats (tránh lộ path/token khi export). */
function extractHostname(baseUrl) {
  try {
    return new URL(baseUrl).hostname || '';
  } catch (_) {
    return '';
  }
}

// ═══════════════════════════════════════════════════
// MESSAGE LISTENER
// ═══════════════════════════════════════════════════
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request?.type === 'ASK_AI' || request?.type === 'CHAT_CONVERSATION') {
    handleAIRequest(request)
      .then(sendResponse)
      .catch((err) => sendResponse({ success: false, error: err.message || String(err) }));
    return true;
  }

  // ── Fetch ảnh từ background — bypass CORS hoàn toàn ──
  if (request?.type === 'FETCH_IMAGE_BASE64') {
    fetchImageAsBase64(request.url)
      .then(sendResponse)
      .catch(() => sendResponse({ base64: null }));
    return true;
  }

  // ── Xóa cache ──
  if (request?.type === 'CLEAR_CACHE') {
    clearQuestionCache()
      .then(() => sendResponse({ success: true }))
      .catch((err) => sendResponse({ success: false, error: err?.message || String(err) }));
    return true;
  }

  // ── Test kết nối endpoint (popup gọi khi bấm Test) ──
  if (request?.type === 'TEST_CONNECTION') {
    testConnection(request)
      .then(sendResponse)
      .catch((err) => sendResponse({ ok: false, error: err?.message || String(err) }));
    return true;
  }
});

// ── Keyboard shortcuts → forward tới tab hiện tại ──
chrome.commands.onCommand.addListener((command) => {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (tabs[0]?.id) {
      chrome.tabs.sendMessage(tabs[0].id, { type: 'KEYBOARD_COMMAND', command });
    }
  });
});

// ═══════════════════════════════════════════════════
// CACHE
// ═══════════════════════════════════════════════════
const CACHE_TTL_MS = 24 * 60 * 60 * 1000; // 24 giờ

/** Tạo hash đơn giản từ chuỗi để làm cache key */
function simpleHash(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) {
    h = (Math.imul(31, h) + str.charCodeAt(i)) | 0;
  }
  return 'q_' + Math.abs(h).toString(36);
}

async function getCachedResult(payload, richFormat = false, scope = {}) {
  const key = buildCacheKey(payload, richFormat, scope);
  const store = await chrome.storage.local.get(key);
  const entry = store[key];
  if (entry && Date.now() - entry.ts < CACHE_TTL_MS) {
    return { hit: true, data: entry.data };
  }
  return { hit: false };
}

async function setCachedResult(payload, data, richFormat = false, scope = {}) {
  const key = buildCacheKey(payload, richFormat, scope);
  await chrome.storage.local.set({ [key]: { data, ts: Date.now() } });
}

/**
 * Dựng cache key ổn định. Loại bỏ `selected` (lựa chọn của user — không thuộc câu hỏi).
 * scope = { model, endpoint, standard }: đổi model/endpoint không dính cache cũ.
 * Prefix 'v2:' để cache cũ (v1) trượt tự nhiên, không cần migration xóa.
 */
function buildCacheKey(payload, richFormat = false, scope = {}) {
  const stableOptions = (payload.options || []).map(o => ({ index: o.index, text: o.text }));
  const matchPart = Array.isArray(payload.matches)
    ? payload.matches.map(m => m.left + '=>' + (m.options || []).map(o => o.text).join(',')).join('|')
    : '';
  const scopePart = [scope.model || '', scope.endpoint || '', scope.standard || ''].join('|');
  return 'v2:' + simpleHash(scopePart + '#' + payload.title + JSON.stringify(stableOptions) + matchPart + '_' + (richFormat ? '1' : '0'));
}

async function clearQuestionCache() {
  const all = await chrome.storage.local.get(null);
  // Xóa cả key v1 (q_...) lẫn v2 (v2:q_...)
  const cacheKeys = Object.keys(all).filter(k => k.startsWith('q_') || k.startsWith('v2:q_'));
  if (cacheKeys.length) await chrome.storage.local.remove(cacheKeys);
}

// ═══════════════════════════════════════════════════
// STATISTICS
// ═══════════════════════════════════════════════════
async function recordStat(entry) {
  const store = await chrome.storage.local.get('stats');
  const stats = Array.isArray(store.stats) ? store.stats : [];
  stats.push({ ...entry, ts: Date.now() });
  // Giữ tối đa 500 bản ghi
  if (stats.length > 500) stats.splice(0, stats.length - 500);
  await chrome.storage.local.set({ stats });
}

// ═══════════════════════════════════════════════════
// FETCH ẢNH
// ═══════════════════════════════════════════════════
async function fetchImageAsBase64(url) {
  try {
    // credentials:'include' để mang theo cookie phiên đăng nhập LMS — bắt buộc
    // cho file Canvas dạng /courses/.../files/.../preview.
    const resp = await fetch(url, { credentials: 'include' });
    if (!resp.ok) {
      console.error('[HoangDZ-BG] HTTP lỗi khi fetch ảnh:', resp.status, url);
      return { base64: null, error: `HTTP ${resp.status}` };
    }
    const buffer = await resp.arrayBuffer();
    const bytes = new Uint8Array(buffer);
    let binary = '';
    const chunkSize = 8192;
    for (let i = 0; i < bytes.length; i += chunkSize) {
      binary += String.fromCharCode(...bytes.subarray(i, i + chunkSize));
    }
    const base64 = btoa(binary);
    const mimeType = resp.headers.get('content-type') || 'image/png';
    return { base64: `data:${mimeType};base64,${base64}` };
  } catch (err) {
    console.error('[HoangDZ-BG] Exception fetch ảnh:', url, err.message);
    return { base64: null, error: err.message };
  }
}

// ═══════════════════════════════════════════════════
// HANDLE AI REQUEST
// ═══════════════════════════════════════════════════

function compareAnswers(d1, d2, type) {
  if (!d1 || !d2) return false;
  if (type === 'multiple_choice') {
    return Boolean(d1.correct_index && d2.correct_index && String(d1.correct_index) === String(d2.correct_index));
  }
  if (type === 'multiple_answers') {
    const a1 = Array.isArray(d1.correct_indices) ? d1.correct_indices.map(String).sort().join(',') : '';
    const a2 = Array.isArray(d2.correct_indices) ? d2.correct_indices.map(String).sort().join(',') : '';
    return Boolean(a1 && a2 && a1 === a2);
  }
  if (type === 'fill_in') {
    const s1 = String(d1.answer || d1.correct_text || '').trim().toLowerCase().replace(/[\s\-_.,*`]/g, '');
    const s2 = String(d2.answer || d2.correct_text || '').trim().toLowerCase().replace(/[\s\-_.,*`]/g, '');
    return Boolean(s1 && s2 && s1 === s2);
  }
  if (type === 'matching') {
    const m1 = JSON.stringify(d1.matches || []);
    const m2 = JSON.stringify(d2.matches || []);
    return m1 === m2;
  }
  return false;
}

function getAnswerSummary(d, type) {
  if (!d) return '';
  if (type === 'multiple_choice') {
    return `${d.correct_index || ''}. ${d.correct_text || ''}`.trim();
  }
  if (type === 'multiple_answers') {
    return (d.correct_indices || []).join(', ');
  }
  if (type === 'fill_in') {
    return String(d.answer || d.correct_text || '').trim();
  }
  return String(d.answer || d.correct_text || '').trim();
}

async function handleAIRequest(req) {
  const settings = await chrome.storage.local.get([
    'providerId', 'modelName', 'model2Name', 'dualModelEnabled', 'apiKey', 'chatHistory', 'richFormat',
    'apiBaseUrl', 'apiStandard', 'apiBaseUrl2', 'apiStandard2', 'apiKey2'
  ]);

  const apiKey = settings.apiKey;
  const modelName = settings.modelName || STORAGE_DEFAULTS.modelName;
  const richFormat = settings.richFormat === true;
  // Keys mới — user cũ thiếu key → default, hành vi y hệt trước đây (tương thích ngược)
  const baseUrl = normalizeBaseUrl(settings.apiBaseUrl ?? STORAGE_DEFAULTS.apiBaseUrl);
  const standard = resolveStandard(baseUrl, settings.apiStandard ?? STORAGE_DEFAULTS.apiStandard);
  const host = extractHostname(baseUrl);

  // Model 2 endpoint & key (cho phép nhập riêng hoặc dùng chung Model 1)
  const baseUrl2 = settings.apiBaseUrl2?.trim()
    ? normalizeBaseUrl(settings.apiBaseUrl2.trim())
    : baseUrl;
  const apiKey2 = settings.apiKey2?.trim()
    ? settings.apiKey2.trim()
    : apiKey;
  const standard2 = resolveStandard(baseUrl2, settings.apiStandard2 ?? 'auto');
  const model2Name = settings.model2Name?.trim() || null;

  // Chế độ Dual-Model: bật khi toggle on và có tên model 2
  const isDual = settings.dualModelEnabled === true && Boolean(model2Name) && (model2Name !== modelName || baseUrl2 !== baseUrl || apiKey2 !== apiKey);

  if (!apiKey) return { success: false, error: 'Chưa cấu hình API Key.' };
  if (isDual && !apiKey2) return { success: false, error: 'Chưa cấu hình API Key cho Model 2.' };

  if (req.type === 'ASK_AI') {
    const mode = req.mode || 'portal';
    const payload = req.payload || {};
    const images = Array.isArray(payload.images) ? payload.images : [];

    const cacheScope = {
      model: isDual ? `${modelName}__dual__${model2Name}` : modelName,
      endpoint: isDual ? `${baseUrl}|${baseUrl2}` : baseUrl,
      standard: isDual ? `${standard}|${standard2}` : standard
    };

    // ── Kiểm tra cache (chỉ cache khi không có ảnh) ──
    if (images.length === 0) {
      const cached = await getCachedResult(payload, richFormat, cacheScope);
      if (cached.hit) {
        console.log('[HoangDZ-BG] Cache hit!');
        const dualHost = isDual ? (host === extractHostname(baseUrl2) ? host : `${host} + ${extractHostname(baseUrl2)}`) : host;
        await recordStat({ model: isDual ? `${modelName} & ${model2Name}` : modelName, host: dualHost, standard, questionType: payload.questionType, cached: true, confidence: cached.data.confidence, inTokens: 0, outTokens: 0 });
        return { success: true, data: cached.data, fromCache: true, model: isDual ? `${modelName} & ${model2Name}` : modelName, standard, usage: { inTokens: 0, outTokens: 0 } };
      }
    }

    const prompt = buildQuizPrompt(payload, mode, richFormat);

    // ── XỬ LÝ DUAL-MODEL VOTING NẾU ĐƯỢC BẬT ──
    if (isDual) {
      const [res1, res2] = await Promise.allSettled([
        callAIWithRetry({ apiKey, modelName, prompt, images, baseUrl, standard }),
        callAIWithRetry({ apiKey: apiKey2, modelName: model2Name, prompt, images, baseUrl: baseUrl2, standard: standard2 })
      ]);

      if (res1.status === 'fulfilled' && res2.status === 'fulfilled') {
        const u1 = res1.value.usage || { inTokens: 0, outTokens: 0 };
        const u2 = res2.value.usage || { inTokens: 0, outTokens: 0 };
        const totalUsage = {
          inTokens: (u1.inTokens || 0) + (u2.inTokens || 0),
          outTokens: (u1.outTokens || 0) + (u2.outTokens || 0)
        };

        const data1 = parseAIResponse(res1.value.text, payload);
        const data2 = parseAIResponse(res2.value.text, payload);

        const isAgreed = compareAnswers(data1, data2, payload.questionType);

        const mergedData = {
          ...data1,
          dualVoting: {
            enabled: true,
            agreement: isAgreed,
            model1: {
              name: modelName,
              answer: getAnswerSummary(data1, payload.questionType),
              data: data1
            },
            model2: {
              name: model2Name,
              answer: getAnswerSummary(data2, payload.questionType),
              data: data2
            }
          }
        };

        if (isAgreed) {
          mergedData.confidence = 1.0; // 100% khi cả 2 model đồng thuận!
        } else {
          mergedData.confidence = 0.49; // Lệch đáp án
        }

        if (images.length === 0) await setCachedResult(payload, mergedData, richFormat, cacheScope);

        const host2 = extractHostname(baseUrl2);
        const dualHost = host === host2 ? host : `${host} + ${host2}`;
        const dualStandard = standard === standard2 ? standard : `${standard}/${standard2}`;

        await recordStat({
          model: `${modelName} & ${model2Name}`, host: dualHost, standard: dualStandard,
          questionType: payload.questionType, cached: false,
          confidence: mergedData.confidence,
          inTokens: totalUsage.inTokens, outTokens: totalUsage.outTokens
        });

        return {
          success: true,
          data: mergedData,
          raw: res1.value.text,
          fromCache: false,
          model: `${modelName} & ${model2Name}`,
          standard: dualStandard,
          usage: totalUsage
        };
      } else if (res1.status === 'fulfilled' || res2.status === 'fulfilled') {
        const okRes = res1.status === 'fulfilled' ? res1.value : res2.value;
        const usedModel = res1.status === 'fulfilled' ? modelName : model2Name;
        const failedModel = res1.status === 'fulfilled' ? model2Name : modelName;
        const usedStandard = res1.status === 'fulfilled' ? standard : standard2;
        const data = parseAIResponse(okRes.text, payload);
        data.dualVoting = {
          enabled: true,
          agreement: false,
          partialError: true,
          warning: `Chỉ model ${usedModel} phản hồi (model ${failedModel} bị lỗi/timeout).`
        };
        const usage = okRes.usage || { inTokens: 0, outTokens: 0 };
        return { success: true, data, raw: okRes.text, fromCache: false, model: usedModel, standard: usedStandard, usage };
      } else {
        throw new Error(`Cả 2 model đều lỗi. Model 1: ${res1.reason?.message || 'lỗi'}; Model 2: ${res2.reason?.message || 'lỗi'}`);
      }
    }

    // ── Single-model bình thường ──
    const { text: rawText, usage } = await callAIWithRetry({ apiKey, modelName, prompt, images, baseUrl, standard });
    const data = parseAIResponse(rawText, payload);

    // ── Lưu cache ──
    if (images.length === 0) await setCachedResult(payload, data, richFormat, cacheScope);

    // ── Ghi thống kê ──
    await recordStat({ model: modelName, host, standard, questionType: payload.questionType, cached: false, confidence: data.confidence, inTokens: usage.inTokens, outTokens: usage.outTokens });

    return { success: true, data, raw: rawText, fromCache: false, model: modelName, standard, usage };
  }

  // CHAT_CONVERSATION
  const history = Array.isArray(settings.chatHistory) ? settings.chatHistory.slice(-10) : [];
  const prompt = buildChatPrompt(history, req.text || '', richFormat);
  const chatImages = Array.isArray(req.images) ? req.images : [];
  const { text: reply, usage: chatUsage } = await callAIWithRetry({ apiKey, modelName, prompt, images: chatImages, baseUrl, standard });

  history.push({ role: 'user', text: req.text || '' });
  history.push({ role: 'assistant', text: reply });
  await chrome.storage.local.set({ chatHistory: history.slice(-20) });
  await recordStat({ model: modelName, host, standard, questionType: 'chat', cached: false, confidence: null, inTokens: chatUsage.inTokens, outTokens: chatUsage.outTokens });

  return { success: true, reply, model: modelName, standard, usage: chatUsage };
}

// ═══════════════════════════════════════════════════
// PROMPT BUILDERS
// ═══════════════════════════════════════════════════
const RICH_FORMAT_INSTRUCTION = `
Định dạng phần "answer", "correct_text" và "explanation":
- Dùng **bold** để nhấn mạnh.
- Dùng \\n để xuống dòng giữa các bước.
- BẮT BUỘC dùng LaTeX inline $...$ cho CÁC CÔNG THỨC/KÝ HIỆU TOÁN (ví dụ: $x^2 + y^2$).
- Dùng LaTeX block $$...$$ cho công thức lớn.
- Ký hiệu đặc biệt: dùng → thay "ra", ≈ thay "xấp xỉ", ± thay "cộng trừ".`;

function buildQuizPrompt(payload = {}, mode = 'portal', richFormat = false) {
  const {
    title = '',
    options = [],
    questionType = 'multiple_choice',
    canvasType = '',
    hasImages = false,
    imageAlts = [],
    images = [],
    matches = [],
  } = payload;

  const isFillin = questionType === 'fill_in' || (questionType === 'multiple_choice' && (!options || options.length === 0));
  const hasVision = images.length > 0;

  const imageNote = hasImages && !hasVision
    ? `\n[Lưu ý: Câu hỏi có hình ảnh (${imageAlts.join(', ')}) nhưng không thể tải được. Phân tích dựa trên text có sẵn.]`
    : hasVision
      ? `\n[ℹ️ ${images.length} hình ảnh đã được đính kèm — hãy phân tích cả hình vẽ.]`
      : '';

  const formatNote = richFormat ? RICH_FORMAT_INSTRUCTION : '';

  if (questionType === 'matching') {
    const linesText = matches.map(m => {
      const choices = (m.options || []).map(o => o.text).join(' | ');
      return `  ${m.left} — chọn 1 trong: ${choices}`;
    }).join('\n');

    const visionOrder = hasVision
      ? `\n[ℹ️ Các ảnh đính kèm tương ứng LẦN LƯỢT với các mục ${matches.map(m => m.left).join(', ')} theo đúng thứ tự.]`
      : '';

    return `Bạn là AI giải bài tập ghép nối (matching). Mỗi mục bên trái cần ghép với MỘT nhãn lựa chọn. Trả về DUY NHẤT JSON hợp lệ, không markdown bên ngoài JSON.

⚠️ RÀNG BUỘC BẮT BUỘC:
- Mỗi mục PHẢI được ghép với MỘT nhãn nằm trong danh sách lựa chọn của chính mục đó.
- "answer" phải là NỘI DUNG NGUYÊN VĂN của một lựa chọn (ví dụ: "(c)"), TUYỆT ĐỐI KHÔNG tự tạo nhãn mới.
- Trả về đủ tất cả các mục.

Schema:
{
  "matches": [ { "left": string, "answer": string } ],
  "explanation": string,
  "confidence": number
}

Quy tắc:
- left: sao chép đúng định danh mục (ví dụ "(1)").
- answer: nhãn được chọn cho mục đó (ví dụ "(c)").
- explanation: giải thích ngắn gọn cách ghép.
- confidence: từ 0 đến 1.${formatNote}${imageNote}${visionOrder}

Loại câu hỏi: ${canvasType || 'matching_question'}

Đề bài:
${title}

Các mục cần ghép (ghép mỗi mục với MỘT nhãn):
${linesText}`;
  }

  if (isFillin) {
    return `Bạn là AI chuyên giải bài tập toán/kỹ thuật. Hãy giải câu hỏi sau và trả về DUY NHẤT JSON hợp lệ, không markdown bên ngoài JSON, không giải thích ngoài JSON.

Schema:
{
  "answer": string,
  "explanation": string,
  "confidence": number
}

Quy tắc:
- answer: kết quả số thập phân (mặc định làm tròn chính xác đến 4 chữ số sau dấu phẩy trừ khi đề bài yêu cầu khác).
- explanation: trình bày các bước tính toán.
- confidence: từ 0 đến 1.
- Nếu câu hỏi yêu cầu điền 0 khi không tuần hoàn, hãy kiểm tra và điền đúng.${formatNote}${imageNote}

Loại câu hỏi: ${canvasType || 'numerical/short_answer'}

Câu hỏi:
${title}`;

  } else if (questionType === 'multiple_answers') {
    const optionsText = options.length
      ? options.map(o => `  ${o.index}. ${o.text}${o.selected ? '  ← [ĐANG ĐƯỢC CHỌN]' : ''}`).join('\n')
      : '(Không có đáp án text — câu hỏi có thể chứa hình ảnh)';

    return `Bạn là AI giải câu hỏi trắc nghiệm dạng CHỌN NHIỀU (multiple answers). Câu này có thể có TỪ 1 ĐẾN NHIỀU đáp án đúng. Trả về DUY NHẤT JSON hợp lệ, không markdown bên ngoài JSON.

⚠️ RÀNG BUỘC BẮT BUỘC:
- Chỉ được chọn các đáp án nằm trong danh sách bên dưới, KHÔNG tự bịa.
- "correct_indices" là MẢNG số thứ tự đáp án đúng (có thể 1 hoặc nhiều).
- Liệt kê đầy đủ TẤT CẢ đáp án đúng (không bỏ sót).

Schema:
{
  "correct_indices": number[],
  "correct_texts": string[],
  "explanation": string,
  "confidence": number
}

Quy tắc:
- correct_indices: ví dụ [1, 3, 4].
- correct_texts: nội dung nguyên văn các đáp án tương ứng.
- explanation: giải thích vì sao những đáp án đó đúng (và những đáp án khác sai).
- confidence: từ 0 đến 1.${formatNote}${imageNote}

Loại câu hỏi: ${canvasType || 'multiple_answers_question'}

Câu hỏi:
${title}

Danh sách đáp án (chọn TẤT CẢ đáp án đúng):
${optionsText}`;

  } else {
    const selectedOption = options.find(o => o.selected);
    const optionsText = options.length
      ? options.map(o => `  ${o.index}. ${o.text}${o.selected ? '  ← [ĐANG ĐƯỢC CHỌN]' : ''}`).join('\n')
      : '(Không có đáp án text — câu hỏi có thể chứa hình ảnh)';

    const selectedNote = selectedOption
      ? `\n\n⚠️ LƯU Ý: Người dùng đã chọn đáp án ${selectedOption.index} ("${selectedOption.text}"). Xác nhận đúng/sai và giải thích.`
      : '';

    return `Bạn là AI giải câu hỏi trắc nghiệm. Hãy phân tích và trả về DUY NHẤT JSON hợp lệ, không markdown bên ngoài JSON, không giải thích ngoài JSON.

⚠️ RÀNG BUỘC BẮT BUỘC:
- Bạn CHỈ được chọn MỘT trong các đáp án đã cho bên dưới.
- TUYỆT ĐỐI KHÔNG tự tạo ra đáp án mới.
- correct_index phải là số thứ tự của một đáp án trong danh sách.
- correct_text phải là NỘI DUNG NGUYÊN VĂN của đáp án đó.

Schema:
{
  "correct_index": number,
  "correct_text": string,
  "explanation": string,
  "confidence": number
}

Quy tắc:
- correct_index: số thứ tự đáp án đúng (1, 2, 3, 4...).
- correct_text: sao chép nguyên văn nội dung đáp án.
- explanation: giải thích tại sao đáp án đó đúng.
- confidence: từ 0 đến 1.${formatNote}${imageNote}${selectedNote}

Loại câu hỏi: ${canvasType || 'multiple_choice'}

Câu hỏi:
${title}

Danh sách đáp án (CHỈ chọn trong số này):
${optionsText}`;
  }
}

function buildChatPrompt(history, message, richFormat = false) {
  const historyText = history
    .map(m => `${m.role === 'assistant' ? 'AI' : 'User'}: ${m.text}`)
    .join('\n');

  const formatNote = richFormat
    ? '\nKhi giải thích công thức, dùng LaTeX $...$ và $$...$$ và Markdown **bold**.'
    : '';

  return `Bạn là trợ lý AI ngắn gọn, hữu ích, trả lời bằng tiếng Việt nếu người dùng dùng tiếng Việt.${formatNote}

Lịch sử gần đây:
${historyText || '(chưa có)'}

Tin nhắn mới:
${message}`;
}

// ═══════════════════════════════════════════════════
// API CALL + AUTO RETRY (DUAL STANDARD)
// ═══════════════════════════════════════════════════
function isRetryableError(err) {
  const msg = err.message || '';
  // Retry khi rate limit (429), server error (5xx), overloaded (529 Anthropic)
  return /429|500|502|503|504|529|rate.?limit|overloaded|timeout/i.test(msg);
}

function sleep(ms) {
  return new Promise(r => setTimeout(r, ms));
}

/** Gọi AI với tự động thử lại 3 lần khi gặp lỗi có thể retry */
async function callAIWithRetry(opts, maxRetries = 3) {
  let lastErr;
  for (let attempt = 1; attempt <= maxRetries; attempt++) {
    try {
      return await callAI(opts);
    } catch (err) {
      lastErr = err;
      console.warn(`[HoangDZ-BG] Lần ${attempt}/${maxRetries} thất bại:`, err.message);
      if (attempt === maxRetries || !isRetryableError(err)) break;
      // Exponential backoff: 1s, 2s, 4s
      await sleep(1000 * Math.pow(2, attempt - 1));
    }
  }
  throw lastErr;
}

/** fetch với timeout — AbortController, throw Error('timeout...') khi quá hạn (match retryable). */
async function fetchWithTimeout(url, options = {}, timeoutMs = AI_TIMEOUT_MS) {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } catch (err) {
    if (err?.name === 'AbortError') {
      throw new Error(`timeout: request quá ${Math.round(timeoutMs / 1000)}s chưa phản hồi`);
    }
    throw err;
  } finally {
    clearTimeout(timer);
  }
}

/**
 * Dispatcher: chọn nhánh gọi API theo chuẩn đã resolve.
 * Trả về { text, usage: { inTokens, outTokens } }.
 */
async function callAI({ apiKey, modelName, prompt, images = [], baseUrl, standard }) {
  const base = normalizeBaseUrl(baseUrl);
  const std = standard === 'anthropic' ? 'anthropic' : 'openai';
  if (std === 'anthropic') {
    return callAnthropicNative({ apiKey, modelName, prompt, images, baseUrl: base });
  }
  return callOpenAICompat({ apiKey, modelName, prompt, images, baseUrl: base });
}

/**
 * Chuẩn OpenAI-compatible: POST {base}/chat/completions, Bearer auth.
 * Nếu `images` có dữ liệu base64, gửi theo format Vision (multimodal content array).
 */
async function callOpenAICompat({ apiKey, modelName, prompt, images = [], baseUrl }) {
  let userContent;
  if (images.length > 0) {
    userContent = [
      { type: 'text', text: prompt },
      ...images.map(dataUrl => ({
        type: 'image_url',
        image_url: { url: dataUrl, detail: 'high' }
      }))
    ];
  } else {
    userContent = prompt;
  }

  const response = await fetchWithTimeout(joinEndpoint(baseUrl, 'openai'), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${apiKey}`
    },
    body: JSON.stringify({
      model: modelName,
      messages: [
        { role: 'system', content: 'Bạn là trợ lý AI giải toán/trắc nghiệm, trả lời bằng tiếng Việt.' },
        { role: 'user', content: userContent }
      ],
      temperature: 0.2,
      stream: false  // Một số model reasoning (claude-opus-4.x...) mặc định stream → ép tắt.
    })
  });

  const rawBody = await response.text();
  const data = parseChatCompletionBody(rawBody);

  if (!response.ok || data?.error) {
    throw new Error(data?.error?.message || `API lỗi HTTP ${response.status}`);
  }

  const text = data?.choices?.[0]?.message?.content?.trim();
  if (!text) throw new Error('API không trả về nội dung.');
  return { text, usage: normalizeUsage(data?.usage, 'openai') };
}

/**
 * Chuẩn Anthropic native: POST {base}/messages, header x-api-key.
 * Vision: image blocks dạng base64 (dataUrl → {media_type, data}).
 */
async function callAnthropicNative({ apiKey, modelName, prompt, images = [], baseUrl }) {
  let userContent = prompt;
  if (images.length > 0) {
    const blocks = [{ type: 'text', text: prompt }];
    for (const dataUrl of images) {
      const img = dataUrlToAnthropicImage(dataUrl);
      if (img) blocks.push(img);
      else console.warn('[HoangDZ-BG] Bỏ qua ảnh không parse được (Anthropic vision).');
    }
    userContent = blocks;
  }

  const response = await fetchWithTimeout(joinEndpoint(baseUrl, 'anthropic'), {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': ANTHROPIC_VERSION
    },
    body: JSON.stringify({
      model: modelName,
      max_tokens: ANTHROPIC_MAX_TOKENS,
      temperature: 0.2,
      system: 'Bạn là trợ lý AI giải toán/trắc nghiệm, trả lời bằng tiếng Việt.',
      messages: [{ role: 'user', content: userContent }]
    })
  });

  const rawBody = await response.text();
  const data = parseAnthropicBody(rawBody);

  if (!response.ok || data?.error) {
    throw new Error(data?.error?.message || `Anthropic API lỗi HTTP ${response.status}`);
  }

  const text = (data?.content || [])
    .filter(b => b?.type === 'text' && typeof b.text === 'string')
    .map(b => b.text)
    .join('\n')
    .trim();
  if (!text) throw new Error('Anthropic không trả về nội dung.');
  return { text, usage: normalizeUsage(data?.usage, 'anthropic') };
}

/** Tách dataURL thành image block Anthropic. Hỏng → null (caller skip, không fail request). */
function dataUrlToAnthropicImage(dataUrl) {
  const m = String(dataUrl || '').match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.+)$/);
  if (!m) return null;
  return { type: 'image', source: { type: 'base64', media_type: m[1].toLowerCase(), data: m[2] } };
}

/** Chuẩn hóa usage 2 chuẩn về { inTokens, outTokens }. Thiếu → 0. */
function normalizeUsage(usage, standard) {
  const u = usage || {};
  if (standard === 'anthropic') {
    return { inTokens: u.input_tokens || 0, outTokens: u.output_tokens || 0 };
  }
  return { inTokens: u.prompt_tokens || 0, outTokens: u.completion_tokens || 0 };
}

/**
 * Parse body trả về từ /chat/completions. Ưu tiên JSON đơn; nếu server vẫn trả SSE
 * (`data: {...}` nhiều dòng — model reasoning dù đã set stream:false), gom các
 * `delta.content` lại thành 1 message hoàn chỉnh. Bỏ qua `reasoning_content`.
 */
function parseChatCompletionBody(text) {
  if (!text) return {};
  const trimmed = text.trim();

  // 1) Thử parse JSON đơn (non-stream, đường happy path)
  try {
    return JSON.parse(trimmed);
  } catch (_) { /* rơi xuống nhánh SSE */ }

  // 2) Nếu trông như SSE (`data: ...` lặp lại) → gộp các delta.content
  if (/^data:\s/m.test(trimmed)) {
    let merged = '';
    let lastErr = null;
    for (const line of trimmed.split(/\r?\n/)) {
      const m = line.match(/^data:\s*(.*)$/);
      if (!m) continue;
      const payload = m[1].trim();
      if (!payload || payload === '[DONE]') continue;
      try {
        const obj = JSON.parse(payload);
        // Lỗi giữa stream
        if (obj.error) lastErr = obj.error;
        const choice = obj.choices?.[0];
        // delta.content (chunk) HOẶC message.content (full)
        const delta = choice?.delta?.content ?? choice?.message?.content;
        if (typeof delta === 'string') merged += delta;
      } catch { /* dòng hỏng — bỏ qua */ }
    }
    if (lastErr) return { error: lastErr };
    if (merged) return { choices: [{ message: { content: merged } }] };
  }

  // 3) Không nhận diện được → coi là lỗi với message thô
  return { error: { message: trimmed.slice(0, 500) || 'Response không phải JSON.' } };
}

/**
 * Parse body trả về từ Anthropic /messages.
 * Thành công: { content:[{type:'text',text}], usage:{input_tokens,output_tokens} }.
 * Lỗi: { error:{message} }.
 */
function parseAnthropicBody(text) {
  if (!text) return {};
  const trimmed = text.trim();
  try {
    return JSON.parse(trimmed);
  } catch (_) {
    return { error: { message: trimmed.slice(0, 500) || 'Response không phải JSON.' } };
  }
}

// ═══════════════════════════════════════════════════
// TEST CONNECTION
// ═══════════════════════════════════════════════════
/**
 * Probe endpoint do popup gọi khi bấm Test.
 * - standard chọn tay → probe đúng chuẩn đó.
 * - auto → probe theo detect, nếu lỗi 404/not-found thì thử chuẩn còn lại 1 lần.
 * Trả về { ok, detectedStandard, latencyMs, models?, error? }.
 * Lưu ý: KHÔNG dùng fallback chéo trong luồng ask thật (tránh double-billing).
 */
async function testConnection({ baseUrl, apiKey, standard, modelName } = {}) {
  const base = normalizeBaseUrl(baseUrl);
  const setting = standard === 'openai' || standard === 'anthropic' ? standard : 'auto';
  const t0 = Date.now();

  const probe = async (std) => {
    if (std === 'anthropic') {
      try {
        const mResp = await fetchWithTimeout(base.replace(/\/+$/, '').replace(/\/messages$/, '') + '/models', {
          method: 'GET',
          headers: {
            'x-api-key': apiKey || '',
            'anthropic-version': ANTHROPIC_VERSION
          }
        }, 15000);
        if (mResp.ok) {
          const mData = await mResp.json().catch(() => ({}));
          let ids = [];
          if (Array.isArray(mData)) ids = mData.map(m => typeof m === 'string' ? m : (m?.id || m?.name)).filter(Boolean);
          else if (Array.isArray(mData?.data)) ids = mData.data.map(m => typeof m === 'string' ? m : (m?.id || m?.name)).filter(Boolean);
          else if (Array.isArray(mData?.models)) ids = mData.models.map(m => typeof m === 'string' ? m : (m?.id || m?.name)).filter(Boolean);
          if (ids.length > 0) return { models: ids };
        }
      } catch (_) {}
      const resp = await fetchWithTimeout(joinEndpoint(base, 'anthropic'), {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'x-api-key': apiKey || '',
          'anthropic-version': ANTHROPIC_VERSION
        },
        body: JSON.stringify({
          model: modelName || 'claude-haiku-4-5',
          max_tokens: 1,
          messages: [{ role: 'user', content: 'ping' }]
        })
      }, 30000);
      const bodyText = await resp.text();
      const data = parseAnthropicBody(bodyText);
      if (!resp.ok || data?.error) {
        throw new Error(data?.error?.message || `HTTP ${resp.status}`);
      }
      return { models: null };
    }
    // OpenAI-compatible: thử GET /models trước (rẻ + thu được model list)
    try {
      const resp = await fetchWithTimeout(base.replace(/\/+$/, '') + '/models', {
        method: 'GET',
        headers: {
          'Authorization': `Bearer ${apiKey || ''}`,
          'x-api-key': apiKey || '',
          'api-key': apiKey || ''
        }
      }, 30000);
      if (resp.ok) {
        const data = await resp.json().catch(() => ({}));
        let ids = [];
        if (Array.isArray(data)) {
          ids = data.map(m => typeof m === 'string' ? m : (m?.id || m?.name)).filter(Boolean);
        } else if (Array.isArray(data?.data)) {
          ids = data.data.map(m => typeof m === 'string' ? m : (m?.id || m?.name)).filter(Boolean);
        } else if (Array.isArray(data?.models)) {
          ids = data.models.map(m => typeof m === 'string' ? m : (m?.id || m?.name)).filter(Boolean);
        }
        return { models: ids };
      }
      // GET không hỗ trợ (404/405...) → rơi xuống probe POST
      if (resp.status !== 404 && resp.status !== 405 && resp.status !== 501) {
        const bodyText = await resp.text().catch(() => '');
        throw new Error(bodyText.slice(0, 200) || `HTTP ${resp.status}`);
      }
    } catch (err) {
      // Lỗi mạng/auth thật → báo luôn, không thử POST vô ích
      if (!/404|405|501|not.?found|method/i.test(err.message || '')) throw err;
    }
    const resp = await fetchWithTimeout(joinEndpoint(base, 'openai'), {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${apiKey || ''}`
      },
      body: JSON.stringify({
        model: modelName || 'gpt-4o-mini',
        messages: [{ role: 'user', content: 'ping' }],
        max_tokens: 1,
        stream: false
      })
    }, 30000);
    const bodyText = await resp.text();
    const data = parseChatCompletionBody(bodyText);
    if (!resp.ok || data?.error) {
      throw new Error(data?.error?.message || `HTTP ${resp.status}`);
    }
    return { models: null };
  };

  try {
    if (setting !== 'auto') {
      const r = await probe(setting);
      return { ok: true, detectedStandard: setting, latencyMs: Date.now() - t0, models: r.models };
    }
    const first = resolveStandard(base, 'auto');
    try {
      const r = await probe(first);
      return { ok: true, detectedStandard: first, latencyMs: Date.now() - t0, models: r.models };
    } catch (err) {
      // Chỉ thử chuẩn còn lại khi lỗi gợi ý sai path/chuẩn
      if (!/404|405|501|not.?found|no route|unknown.*(path|endpoint|model)/i.test(err.message || '')) throw err;
      const second = first === 'anthropic' ? 'openai' : 'anthropic';
      const r = await probe(second);
      return { ok: true, detectedStandard: second, latencyMs: Date.now() - t0, models: r.models };
    }
  } catch (err) {
    return { ok: false, detectedStandard: null, latencyMs: Date.now() - t0, error: err?.message || String(err) };
  }
}

// ═══════════════════════════════════════════════════
// PARSE AI RESPONSE
// ═══════════════════════════════════════════════════
function parseAIResponse(rawText, payload = {}) {
  const cleaned = String(rawText || '')
    .replace(/```json/gi, '')
    .replace(/```/g, '')
    .trim();

  let parsed;
  try {
    parsed = JSON.parse(cleaned);
  } catch (_) {
    const match = cleaned.match(/\{[\s\S]*\}/);
    if (!match) throw new Error('AI không trả về JSON hợp lệ. Nội dung: ' + cleaned.slice(0, 300));
    parsed = JSON.parse(match[0]);
  }

  const isFillin = payload.questionType === 'fill_in' || (payload.questionType === 'multiple_choice' && (!payload.options || payload.options.length === 0));

  if (payload.questionType === 'matching') {
    const payloadMatches = Array.isArray(payload.matches) ? payload.matches : [];
    const aiMatches = Array.isArray(parsed.matches) ? parsed.matches : [];

    // Map theo index nếu cùng số lượng; nếu lệch, thử khớp theo "left"
    const resolved = payloadMatches.map((pm, i) => {
      let raw = aiMatches[i];
      if (!raw || (raw.left && String(raw.left).trim() !== String(pm.left).trim())) {
        const found = aiMatches.find(a => String(a.left || '').trim() === String(pm.left).trim());
        if (found) raw = found;
      }
      const rawAns = String(raw?.answer ?? raw?.right ?? raw?.value ?? '').trim();
      const ansLow = rawAns.toLowerCase();

      // Tìm option khớp (exact → includes 2 chiều)
      let opt = pm.options.find(o => o.text.toLowerCase() === ansLow);
      if (!opt && ansLow) {
        opt = pm.options.find(o => {
          const t = o.text.toLowerCase();
          return t.includes(ansLow) || ansLow.includes(t);
        });
      }
      // Fallback: AI có thể trả "value" trực tiếp (match-id)
      if (!opt && raw?.value) {
        opt = pm.options.find(o => o.value === String(raw.value));
      }

      return {
        index: pm.index,
        left: pm.left,
        answer: opt?.text || rawAns,
        value: opt?.value || '',
      };
    });

    return {
      questionType: 'matching',
      matches: resolved,
      explanation: String(parsed.explanation || parsed.reason || 'Không có giải thích.'),
      confidence: typeof parsed.confidence === 'number' ? parsed.confidence : null,
    };
  }

  if (payload.questionType === 'multiple_answers') {
    // Chuẩn hóa correct_indices: mảng số / string số / chữ cái A-Z
    const rawArr = Array.isArray(parsed.correct_indices)
      ? parsed.correct_indices
      : Array.isArray(parsed.correct_index) ? parsed.correct_index
      : (parsed.correct_indices != null ? [parsed.correct_indices] : []);

    const indices = rawArr.map(v => {
      if (typeof v === 'number') return v;
      const s = String(v).trim().toUpperCase();
      if (/^[A-Z]$/.test(s)) return s.charCodeAt(0) - 64;
      const n = parseInt(s, 10);
      return Number.isInteger(n) ? n : null;
    }).filter(n => Number.isInteger(n) && n >= 1);

    // Bổ sung qua correct_texts nếu thiếu
    const rawTexts = Array.isArray(parsed.correct_texts) ? parsed.correct_texts
      : Array.isArray(parsed.correct_text) ? parsed.correct_text : [];
    rawTexts.forEach(txt => {
      const t = String(txt).toLowerCase().trim();
      if (!t || !Array.isArray(payload.options)) return;
      const m = payload.options.find(o => {
        const ot = String(o.text || '').toLowerCase().trim();
        return ot && (ot === t || ot.includes(t) || t.includes(ot));
      });
      if (m && !indices.includes(m.index)) indices.push(m.index);
    });

    if (indices.length === 0) {
      console.error('[HoangDZ] multiple_answers parse thất bại. Raw:', rawText);
      throw new Error('AI không trả về danh sách đáp án hợp lệ. Raw: ' + cleaned.slice(0, 200));
    }

    // Map texts theo indices
    const texts = indices.map(i => {
      if (Array.isArray(payload.options)) {
        const o = payload.options.find(opt => opt.index === i);
        if (o) return o.text;
      }
      return '';
    });

    return {
      questionType: 'multiple_answers',
      correct_indices: indices,
      correct_texts: texts,
      explanation: String(parsed.explanation || parsed.reason || 'Không có giải thích.'),
      confidence: typeof parsed.confidence === 'number' ? parsed.confidence : null,
    };
  }

  if (isFillin) {
    return {
      questionType: 'fill_in',
      answer: String(parsed.answer ?? parsed.correct_text ?? parsed.result ?? ''),
      explanation: String(parsed.explanation || parsed.reason || 'Không có giải thích.'),
      confidence: typeof parsed.confidence === 'number' ? parsed.confidence : null,
    };
  }

  // ── Normalize correct_index: hỗ trợ số, string số, và chữ cái A/B/C/D ──
  let rawIndex = parsed.correct_index ?? parsed.answer ?? parsed.index ?? parsed.correct_option;
  let correctIndex;

  if (typeof rawIndex === 'string') {
    const upper = rawIndex.trim().toUpperCase();
    if (/^[A-E]$/.test(upper)) {
      correctIndex = upper.charCodeAt(0) - 64;
    } else {
      correctIndex = parseInt(upper, 10);
    }
  } else {
    correctIndex = Number(rawIndex);
  }

  // Nếu vẫn không hợp lệ, tìm theo correct_text
  if (!Number.isInteger(correctIndex) || correctIndex < 1) {
    const correctText = String(parsed.correct_text || parsed.answer_text || '').toLowerCase().trim();
    if (correctText && Array.isArray(payload.options)) {
      const matched = payload.options.find(o =>
        String(o.text || '').toLowerCase().trim().includes(correctText) ||
        correctText.includes(String(o.text || '').toLowerCase().trim())
      );
      if (matched) correctIndex = matched.index;
    }
  }

  if (!Number.isInteger(correctIndex) || correctIndex < 1) {
    console.error('[HoangDZ] parseAIResponse thất bại. Raw AI:', rawText);
    throw new Error(`AI trả về correct_index không hợp lệ: "${rawIndex}". Raw: ${cleaned.slice(0, 200)}`);
  }

  let correctText = String(parsed.correct_text || parsed.answer_text || '');
  if (!correctText && Array.isArray(payload.options)) {
    const opt = payload.options.find(o => o.index === correctIndex);
    if (opt) correctText = opt.text || '';
  }

  return {
    questionType: 'multiple_choice',
    correct_index: correctIndex,
    correct_text: correctText,
    explanation: String(parsed.explanation || parsed.reason || 'Không có giải thích.'),
    confidence: typeof parsed.confidence === 'number' ? parsed.confidence : null,
  };
}
