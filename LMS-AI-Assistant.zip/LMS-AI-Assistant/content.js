﻿(function () {

  // ═══════════════════════════════════════════════════
  // SELECTORS theo từng chế độ trang
  // ═══════════════════════════════════════════════════
  const SELECTORS = {
    // LMS cũ (e-learning.hust / moodle-style)
    lms: {
      container: '.question-container',
      questionItem: '.question-item',
      questionTitle: '.question-title',
      option: '.checkbox',
    },
    // Canvas Portal (portal.uet.vnu.edu.vn)
    portal: {
      container: '#questions',
      questionItem: '.display_question',
      questionTitle: '.question_text',
      option: '.answer',
    },
    // LMS VNU Moodle (lms.vnu.edu.vn) — quiz attempt: mỗi câu là .que
    vnu: {
      container: '#page-content, #region-main, .que',
      questionItem: '.que',
      questionTitle: '.qtext',
      option: '.answer',
    }
  };

  /** Tự nhận diện chế độ theo URL — dùng khi user chưa chọn tay trong popup. */
  function detectModeFromUrl() {
    const url = (typeof location !== 'undefined' ? location.href : '') || '';
    if (url.includes('lms.vnu.edu.vn')) return 'vnu';

    return 'portal';
  }

  /** Chuẩn hóa mode: giá trị lưu → fallback tự nhận diện URL → portal. */
  function resolveMode(saved) {
    if (saved === 'portal' || saved === 'vnu') return saved;
    return detectModeFromUrl();
  }

  // ═══════════════════════════════════════════════════
  // STATE
  // ═══════════════════════════════════════════════════
  let currentMode = 'portal';
  let extensionEnabled = true;
  let richFormat = false;
  let autoFillEnabled = true;
  let stealthUIEnabled = false;
  let microDotMode = false;
  let pacingDelaySetting = 'normal';
  let bossHidden = false;
  let observerStarted = false;
  let currentSelectors = SELECTORS.portal;
  // Auto-fill chỉ chạy khi đang trong vòng "Hỏi tất cả".
  // Bấm hỏi 1 câu lẻ → chỉ gợi ý, KHÔNG fill (tránh điền nhầm khi user còn cân nhắc).
  let isAskAllRunning = false;

  // ═══════════════════════════════════════════════════
  // ICONS — SVG line mảnh đơn sắc (thay toàn bộ emoji AI-style)
  // ═══════════════════════════════════════════════════
  const SVG_PATHS = {
    spark: '<path d="M12 3l1.9 5.7 5.7 1.3-5.7 1.9L12 17.6l-1.9-5.7L4.4 10l5.7-1.3L12 3z"/>',
    play: '<path d="M8 5v14l11-7z" fill="currentColor" stroke="none"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor" stroke="none"/>',
    retry: '<polyline points="23 4 23 10 17 10"/><path d="M20.49 15a9 9 0 1 1-2.12-9.36L23 10"/>',
    chat: '<path d="M21 11.5a8.38 8.38 0 0 1-.9 3.8 8.5 8.5 0 0 1-7.6 4.7 8.38 8.38 0 0 1-3.8-.9L3 21l1.9-5.7a8.38 8.38 0 0 1-.9-3.8 8.5 8.5 0 0 1 4.7-7.6 8.38 8.38 0 0 1 3.8-.9h.5a8.48 8.48 0 0 1 8 8v.5z"/>',
    send: '<line x1="12" y1="19" x2="12" y2="5"/><polyline points="5 12 12 5 19 12"/>',
    clip: '<path d="M21.44 11.05l-9.19 9.19a6 6 0 0 1-8.49-8.49l9.19-9.19a4 4 0 0 1 5.66 5.66l-9.2 9.19a2 2 0 0 1-2.83-2.83l8.49-8.48"/>',
    x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
    trash: '<polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
  };

  function svgIcon(name) {
    return `<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${SVG_PATHS[name] || ''}</svg>`;
  }

  /** Báo cho bypass.js (MAIN world) bật/tắt qua window.postMessage. */
  function notifyBypass(enabled) {
    try {
      window.postMessage({ source: 'lms-ai-assistant', type: 'BYPASS_TOGGLE', enabled }, '*');
    } catch (_) { /* bỏ qua */ }
  }

  // ═══════════════════════════════════════════════════
  // INIT
  // ═══════════════════════════════════════════════════
  
  function injectKatexCss() {
    if (document.getElementById('hoangdz-katex-css')) return;
    const link = document.createElement('link');
    link.id = 'hoangdz-katex-css';
    link.rel = 'stylesheet';
    link.href = chrome.runtime.getURL('katex/katex.min.css');
    document.head.appendChild(link);
  }

  chrome.storage.local.get(['siteMode', 'extensionEnabled', 'richFormat', 'autoFillEnabled', 'stealthUIEnabled', 'microDotMode', 'pacingDelay'], (result) => {
    currentMode = resolveMode(result.siteMode);
    extensionEnabled = result.extensionEnabled !== false;
    richFormat = result.richFormat === true;
    autoFillEnabled = result.autoFillEnabled !== false;
    stealthUIEnabled = result.stealthUIEnabled === true;
    microDotMode = result.microDotMode === true;
    pacingDelaySetting = result.pacingDelay || 'normal';
    currentSelectors = SELECTORS[currentMode] || SELECTORS.portal;
    if (extensionEnabled) {
      injectKatexCss();
      applyStealthUI();
      window.addEventListener('load', () => { startObserver(); createFloatingChat(); });
      startObserver();
      createFloatingChat();
    }
  });

  // Function to apply stealth UI mode
  function applyStealthUI() {
    if (stealthUIEnabled) {
      document.body.classList.add('hoangdz-stealth-mode');
    } else {
      document.body.classList.remove('hoangdz-stealth-mode');
    }
    notifyBypass(stealthUIEnabled);
  }

  // ── Phím tắt Boss Key (Alt + Q) ẩn/hiện tức thì ──
  function toggleBossHide() {
    bossHidden = !bossHidden;
    document.body.classList.toggle('hoangdz-boss-hidden', bossHidden);
  }

  window.addEventListener('keydown', (e) => {
    if (e.altKey && (e.code === 'KeyQ' || e.key === 'q' || e.key === 'Q')) {
      e.preventDefault();
      toggleBossHide();
    }
  });
  // Bật/tắt toàn bộ UI extension
  function applyExtensionEnabled(enabled) {
    extensionEnabled = enabled;
    if (enabled) {
      const existingWrapper = document.getElementById('hoangdz-ai-chat-wrapper');
      if (existingWrapper) existingWrapper.style.display = '';
      else createFloatingChat();
      const banner = document.getElementById('hoangdz-ask-all-banner');
      if (banner) banner.style.display = '';
      startObserver();
      tryInit();
    } else {
      document.querySelectorAll('.hoangdz-ai-action-container').forEach(el => el.remove());
      const chatWrapper = document.getElementById('hoangdz-ai-chat-wrapper');
      if (chatWrapper) chatWrapper.style.display = 'none';
      const banner = document.getElementById('hoangdz-ask-all-banner');
      if (banner) banner.style.display = 'none';
      stopObserver();
    }
  }

  // Sync settings từ chrome.storage để các tab khác (không phải tab active)
  // cũng cập nhật khi popup đổi setting.
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    if ('extensionEnabled' in changes) {
      applyExtensionEnabled(changes.extensionEnabled.newValue !== false);
    }
    if ('siteMode' in changes) {
      currentMode = resolveMode(changes.siteMode.newValue);
      currentSelectors = SELECTORS[currentMode] || SELECTORS.portal;
      if (extensionEnabled) tryInit();
    }
    if ('richFormat' in changes) {
      richFormat = changes.richFormat.newValue === true;
    }
    if ('autoFillEnabled' in changes) {
      autoFillEnabled = changes.autoFillEnabled.newValue !== false;
    }
    if ('stealthUIEnabled' in changes) {
      stealthUIEnabled = changes.stealthUIEnabled.newValue === true;
      applyStealthUI();
    }
    if ('microDotMode' in changes) {
      microDotMode = changes.microDotMode.newValue === true;
      document.querySelectorAll('.hoangdz-ai-result').forEach(c => {
        const hasConflict = c.querySelector('.hoangdz-conflict-box');
        if (microDotMode && !hasConflict) {
          c.style.display = 'none';
          c.classList.add('hoangdz-micro-mode');
        } else {
          c.style.display = '';
          c.classList.remove('hoangdz-micro-mode');
        }
      });
    }
    if ('pacingDelay' in changes) {
      pacingDelaySetting = changes.pacingDelay.newValue || 'normal';
    }
  });

  // Listen for messages from popup / background
  chrome.runtime.onMessage.addListener((msg) => {
    if (msg?.type === 'EXTENSION_TOGGLE') {
      applyExtensionEnabled(msg.enabled);
      return;
    }
    if (msg?.type === 'SITE_MODE_CHANGED') {
      currentMode = resolveMode(msg.siteMode);
      currentSelectors = SELECTORS[currentMode] || SELECTORS.portal;
      if (extensionEnabled) tryInit();
      return;
    }
    if (msg?.type === 'RICH_FORMAT_CHANGED') {
      richFormat = msg.richFormat;
      return;
    }
    if (msg?.type === 'AUTOFILL_CHANGED') {
      autoFillEnabled = msg.autoFillEnabled;
      return;
    }
    if (msg?.type === 'STEALTH_UI_CHANGED') {
      stealthUIEnabled = msg.stealthUIEnabled;
      applyStealthUI();
      return;
    }
    if (msg?.type === 'MICRO_DOT_CHANGED') {
      microDotMode = msg.microDotMode === true;
      return;
    }
    if (msg?.type === 'PACING_DELAY_CHANGED') {
      pacingDelaySetting = msg.pacingDelay || 'normal';
      return;
    }
    // ── Keyboard shortcuts từ background ──
    if (msg?.type === 'KEYBOARD_COMMAND') {
      if (msg.command === 'ask-all') {
        const askAllBtn = document.getElementById('hoangdz-ask-all-btn');
        if (askAllBtn && !askAllBtn.disabled) askAllBtn.click();
      } else if (msg.command === 'toggle-chat') {
        if (!stealthUIEnabled) {
          const box = document.getElementById('hoangdz-ai-chat-box');
          if (box) box.classList.toggle('hoangdz-hidden');
        }
      } else if (msg.command === 'quick-toggle') {
        toggleBossHide();
      }
      return;
    }
  });

  // ═══════════════════════════════════════════════════
  // OBSERVER
  // ═══════════════════════════════════════════════════
  let mutationObserver = null;
  let pollIntervalId = null;
  let steadyInitCount = 0; // Đếm số lần tryInit liên tiếp không thêm nút mới

  function startObserver() {
    if (observerStarted) return;
    observerStarted = true;
    steadyInitCount = 0;

    // Debounce 300ms — tránh mutation burst trên Portal gọi tryInit liên tục
    let debounceTimer = null;
    mutationObserver = new MutationObserver(() => {
      if (debounceTimer) clearTimeout(debounceTimer);
      debounceTimer = setTimeout(tryInit, 300);
    });
    mutationObserver.observe(document.body, { childList: true, subtree: true });

    pollIntervalId = setInterval(tryInit, 2000);
  }

  function stopObserver() {
    if (!observerStarted) return;
    observerStarted = false;
    if (mutationObserver) { mutationObserver.disconnect(); mutationObserver = null; }
    if (pollIntervalId) { clearInterval(pollIntervalId); pollIntervalId = null; }
  }

  function tryInit() {
    if (!extensionEnabled) return;
    const container = document.querySelector(currentSelectors.container);
    const questions = document.querySelectorAll(currentSelectors.questionItem);
    if (container && questions.length) {
      const before = document.querySelectorAll('.hoangdz-ai-action-container').length;
      initExtension();
      const after = document.querySelectorAll('.hoangdz-ai-action-container').length;
      // Ổn định (không thêm nút mới) 5 lần liên tiếp → dừng poll 2s, chỉ giữ observer
      if (after === before) {
        steadyInitCount += 1;
        if (steadyInitCount >= 5 && pollIntervalId) {
          clearInterval(pollIntervalId);
          pollIntervalId = null;
        }
      } else {
        steadyInitCount = 0;
        if (!pollIntervalId && observerStarted) pollIntervalId = setInterval(tryInit, 2000);
      }
    }
  }

  // ═══════════════════════════════════════════════════
  // INJECT BUTTONS
  // ═══════════════════════════════════════════════════
  function initExtension() {
    const questions = document.querySelectorAll(currentSelectors.questionItem);
    questions.forEach((item) => {
      if (item.querySelector('.hoangdz-ai-action-container')) return;

      const actionDiv = document.createElement('div');
      actionDiv.className = 'hoangdz-ai-action-container';

      const btn = document.createElement('button');
      btn.type = 'button';
      btn.innerHTML = `${svgIcon('spark')}<span>Hỏi AI</span>`;
      btn.className = 'hoangdz-ai-btn';
      btn.setAttribute('aria-label', 'Hỏi AI câu này');

      const resultDiv = document.createElement('div');
      resultDiv.className = 'hoangdz-ai-result';
      resultDiv.setAttribute('aria-live', 'polite');

      const setBtnLoading = (label) => {
        btn.disabled = true;
        btn.innerHTML = `<span class="hoangdz-spinner" aria-hidden="true"></span><span>${escapeHtml(label)}</span>`;
      };
      const resetBtn = () => {
        btn.disabled = false;
        btn.innerHTML = `${svgIcon('spark')}<span>Hỏi AI</span>`;
      };

      // Tách logic hỏi thành hàm riêng để nút "Thử lại" tái dùng
      const askQuestion = async () => {
        setBtnLoading('Đang phân tích...');
        resultDiv.textContent = '';
        resultDiv.classList.remove('hoangdz-ai-error');

        const payload = currentMode === 'portal'
          ? extractPortalQuestion(item)
          : currentMode === 'vnu'
            ? extractVnuQuestion(item)
            : extractLmsQuestion(item);

        // ── Vision: fetch images as base64 within page auth context ──
        if (payload.hasImages && payload.imageSrcs?.length) {
          setBtnLoading('Đang tải ảnh...');
          const base64List = await Promise.all(
            payload.imageSrcs.map(src => fetchImageBase64(src))
          );
          payload.images = base64List.filter(Boolean);
          if (payload.images.length === 0) {
            console.warn('[HoangDZ] Không tải được ảnh nào! AI sẽ không nhìn thấy hình.');
          }
        }

        chrome.runtime.sendMessage({ type: 'ASK_AI', payload, mode: currentMode }, (response) => {
          resetBtn();

          if (chrome.runtime.lastError) {
            showError(resultDiv, chrome.runtime.lastError.message, askQuestion);
            return;
          }
          if (!response?.success) {
            showError(resultDiv, response?.error || 'Lỗi không xác định.', askQuestion);
            return;
          }
          showResult(resultDiv, response);
          // Chỉ auto-fill khi đang trong "Hỏi tất cả" — bấm 1 câu lẻ chỉ hiển thị gợi ý.
          if (autoFillEnabled && isAskAllRunning) {
            autoFillAnswer(item, response.data, currentMode);
          }
        });
      };

      btn.addEventListener('click', askQuestion);

      actionDiv.appendChild(btn);
      actionDiv.appendChild(resultDiv);
      item.appendChild(actionDiv);
    });

    // ── "Hỏi tất cả" banner ──
    injectAskAllBanner();
  }

  // ═══════════════════════════════════════════════════
  // ASK-ALL BANNER
  // ═══════════════════════════════════════════════════
  
  function getPacingDelayMs() {
    if (pacingDelaySetting === 'fast') return 1000 + Math.floor(Math.random() * 1000);
    if (pacingDelaySetting === 'slow') return 6000 + Math.floor(Math.random() * 3000);
    return 3000 + Math.floor(Math.random() * 2000);
  }

  function injectAskAllBanner() {
    if (document.getElementById('hoangdz-ask-all-banner')) return;

    const container = document.querySelector(currentSelectors.container);
    if (!container) return;

    const banner = document.createElement('div');
    banner.id = 'hoangdz-ask-all-banner';

    const countEl = document.createElement('span');
    countEl.id = 'hoangdz-ask-all-count';
    updateAskAllCount(countEl);

    const btn = document.createElement('button');
    btn.id = 'hoangdz-ask-all-btn';
    btn.type = 'button';
    btn.setAttribute('aria-label', 'Hỏi tất cả câu hỏi bằng AI');
    btn.innerHTML = `${svgIcon('play')}<span>Hỏi tất cả</span>`;

    const stopBtn = document.createElement('button');
    stopBtn.id = 'hoangdz-ask-all-stop';
    stopBtn.type = 'button';
    stopBtn.setAttribute('aria-label', 'Dừng hỏi tất cả');
    stopBtn.innerHTML = `${svgIcon('stop')}<span>Dừng</span>`;
    stopBtn.style.display = 'none';

    const progressEl = document.createElement('span');
    progressEl.id = 'hoangdz-ask-all-progress';
    progressEl.setAttribute('aria-live', 'polite');

    const exportBtn = document.createElement('button');
    exportBtn.id = 'hoangdz-export-quiz-btn';
    exportBtn.type = 'button';
    exportBtn.className = 'hoangdz-ai-btn hoangdz-export-btn';
    exportBtn.setAttribute('aria-label', 'Xuất toàn bộ câu hỏi và đáp án ra file Markdown');
    exportBtn.innerHTML = `${svgIcon('download')}<span>Xuất đề (.md)</span>`;
    exportBtn.addEventListener('click', exportQuizToMarkdown);

    banner.append(btn, stopBtn, exportBtn, countEl, progressEl);
    container.insertAdjacentElement('beforebegin', banner);

    // ── Cảnh báo SEB / lock màn hình (nếu phát hiện) ──
    const sebInfo = detectSebLockdown();
    if (sebInfo.locked) {
      const warn = document.createElement('div');
      warn.className = 'hoangdz-seb-warn';
      warn.setAttribute('role', 'alert');
      warn.textContent = `Cảnh báo: phát hiện ${sebInfo.reason} — trang thi có thể đang giám sát. Extension không bypass SEB.`;
      banner.appendChild(warn);
    }

    let stopRequested = false;

    btn.addEventListener('click', async () => {
      const allBtns = [...document.querySelectorAll('.hoangdz-ai-btn')]
        .filter(b => !b.disabled && (b.textContent || '').includes('Hỏi AI'));

      if (allBtns.length === 0) {
        progressEl.textContent = 'Không còn câu nào cần hỏi.';
        return;
      }

      stopRequested = false;
      isAskAllRunning = true;  // bật cờ để callback từng câu được phép auto-fill
      btn.disabled = true;
      btn.innerHTML = '<span class="hoangdz-spinner" aria-hidden="true"></span><span>Đang hỏi...</span>';
      stopBtn.style.display = 'inline-flex';
      stopBtn.innerHTML = `${svgIcon('stop')}<span>Dừng</span>`;
      progressEl.textContent = '';

      try {
        for (let i = 0; i < allBtns.length; i++) {
          if (stopRequested) break;

          const qBtn = allBtns[i];
          progressEl.textContent = `${i + 1}/${allBtns.length} · Đang hỏi...`;

          qBtn.click();

          // Chờ cho đến khi nút không còn disabled (AI đã trả lời)
          await waitForButton(qBtn, 60000);

          if (stopRequested) break;

          if (i < allBtns.length - 1) {
            const delayMs = getPacingDelayMs();
            progressEl.textContent = `${i + 1}/${allBtns.length} · Nghỉ ${(delayMs / 1000).toFixed(1)}s...`;
            await sleep(delayMs);
          }
        }
      } finally {
        isAskAllRunning = false;
      }

      btn.disabled = false;
      btn.innerHTML = `${svgIcon('play')}<span>Hỏi tất cả</span>`;
      stopBtn.style.display = 'none';
      progressEl.textContent = stopRequested
        ? 'Đã dừng.'
        : 'Hoàn thành!';
    });

    stopBtn.addEventListener('click', () => {
      stopRequested = true;
      stopBtn.textContent = 'Đang dừng...';
    });
  }

  
  function exportQuizToMarkdown() {
    const items = document.querySelectorAll(currentSelectors.questionItem);
    if (!items.length) {
      alert('Không tìm thấy câu hỏi nào trên trang để xuất.');
      return;
    }
    const quizTitle = document.title || 'Canvas Quiz';
    const dateStr = new Date().toLocaleString('vi-VN');
    let md = `# ${quizTitle}\n\n*Thời gian xuất:* ${dateStr}\n*Tổng số câu:* ${items.length}\n\n---\n\n`;

    items.forEach((item, index) => {
      const qTitle = item.querySelector(currentSelectors.questionTitle)?.innerText?.trim() || `Câu hỏi ${index + 1}`;
      md += `### Câu ${index + 1}: ${qTitle}\n\n`;

      const options = item.querySelectorAll(currentSelectors.option);
      if (options.length > 0) {
        options.forEach((opt, optIndex) => {
          const charLabel = String.fromCharCode(65 + optIndex);
          const optText = opt.innerText?.trim() || '';
          const isChecked = Boolean(opt.querySelector('input:checked'));
          const hasDot = Boolean(opt.querySelector('.hoangdz-micro-dot'));
          const mark = isChecked || hasDot ? '[x]' : '[ ]';
          const note = hasDot ? ' *(Đáp án AI gợi ý)*' : isChecked ? ' *(Đã chọn)*' : '';
          md += `- ${mark} **${charLabel}.** ${optText}${note}\n`;
        });
        md += '\n';
      }

      const resultAnswer = item.querySelector('.hoangdz-ai-answer')?.innerText?.trim();
      const explanation = item.querySelector('.hoangdz-ai-explanation')?.innerText?.trim();
      if (resultAnswer || explanation) {
        if (resultAnswer) md += `> **${resultAnswer}**\n`;
        if (explanation) md += `> ${explanation}\n`;
        md += '\n';
      }
      md += '---\n\n';
    });

    const blob = new Blob([md], { type: 'text/markdown;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    const cleanName = (quizTitle.replace(/[^\w\s\u00C0-\u1EF9-]/gi, '').trim() || 'portal-quiz').slice(0, 40);
    a.href = url;
    a.download = `${cleanName}-${Date.now()}.md`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }

  function updateAskAllCount(el) {
    const n = document.querySelectorAll(currentSelectors.questionItem).length;
    el.textContent = `(${n} câu)`;
  }

  /** Chờ cho đến khi nút không còn bị disabled (hoặc timeout) */
  function waitForButton(btn, timeout = 60000) {
    return new Promise(resolve => {
      if (!btn.disabled) { resolve(); return; }
      const start = Date.now();
      const iv = setInterval(() => {
        if (!btn.disabled || Date.now() - start > timeout) {
          clearInterval(iv);
          resolve();
        }
      }, 300);
    });
  }

  function sleep(ms) {
    return new Promise(r => setTimeout(r, ms));
  }

  /**
   * Phát hiện dấu hiệu SEB / lockdown browser / giám sát thi.
   * Chỉ cảnh báo — extension KHÔNG bypass SEB (SEB chạy trình duyệt riêng,
   * content script Chrome không tồn tại trong đó).
   */
  function detectSebLockdown() {
    try {
      // 1. Safe Exam Browser thật: UA chứa "SEB"
      const ua = navigator.userAgent || '';
      if (/SEB/i.test(ua)) return { locked: true, reason: 'Safe Exam Browser (user-agent)' };
      // 2. Moodle quiz bật Safe Exam Browser (config trong HTML/JS trang)
      const html = document.documentElement?.outerHTML || '';
      if (/seb[_-]?require|safeexambrowser|seb\.config|sebclientsettings/i.test(html)) {
        return { locked: true, reason: 'chế độ Safe Exam Browser của Moodle' };
      }
      // 3. Fullscreen bắt buộc / kiosk / lockdown text hiển thị
      const bodyText = (document.body?.innerText || '').slice(0, 5000);
      if (/safe exam browser|lockdown|khóa màn hình|khoa man hinh/i.test(bodyText)) {
        return { locked: true, reason: 'chế độ khóa màn hình/giám sát' };
      }
      // 4. Đang fullscreen toàn màn hình khi vừa vào trang thi
      if (document.fullscreenElement) {
        return { locked: true, reason: 'fullscreen bắt buộc' };
      }
    } catch (_) { /* bỏ qua */ }
    return { locked: false, reason: '' };
  }

  // ═══════════════════════════════════════════════════
  // EXTRACT — LMS CŨ
  // ═══════════════════════════════════════════════════
  function extractLmsQuestion(item) {
    const title = item.querySelector(SELECTORS.lms.questionTitle)?.innerText?.trim()
      || item.innerText.slice(0, 1000);

    const options = Array.from(item.querySelectorAll(SELECTORS.lms.option)).map((opt, i) => {
      const input = opt.querySelector('input');
      const text = opt.innerText?.trim()
        || opt.querySelector('span')?.innerText?.trim()
        || '';
      return { index: i + 1, text, selected: Boolean(input?.checked) };
    });

    return { title, options, questionType: options.length ? 'multiple_choice' : 'fill_in' };
  }

  // ═══════════════════════════════════════════════════
  // EXTRACT — LMS VNU MOODLE (lms.vnu.edu.vn)
  // Cấu trúc quiz attempt Moodle chuẩn: .que > .qtext (đề) + .answer (đáp án).
  // Hỗ trợ: multichoice (radio/checkbox), truefalse, shortanswer/numerical
  // (input text), match (select), essay (textarea — chỉ đọc đề).
  // ═══════════════════════════════════════════════════
  function extractVnuQuestion(item) {
    const titleEl = item.querySelector(SELECTORS.vnu.questionTitle);
    const title = titleEl
      ? extractTextWithMath(titleEl)
      : (item.innerText || '').slice(0, 1000).trim();

    // Ảnh trong đề (Moodle: /pluginfile.php/... — fetch qua background kèm cookie)
    const imgEls = Array.from(item.querySelectorAll('.qtext img, .answer img'));
    const imageSrcs = imgEls.map(img => img.src).filter(Boolean);
    const imageAlts = imgEls.map(img => img.alt || '(hình vẽ)').filter(Boolean);
    const hasImages = imageSrcs.length > 0;

    // ── Matching (Moodle qtype_match): mỗi dòng là 1 <select> ──
    const matchSelects = [...item.querySelectorAll('.answer select, select.custom-select, select.form-control')];
    if (matchSelects.length > 0) {
      const matches = matchSelects.map((sel, i) => {
        // Label dòng thường nằm ở ô bên trái cùng hàng (tr/td) hoặc text trước select
        const row = sel.closest('tr, .row, div');
        let left = `#${i + 1}`;
        if (row) {
          const clone = row.cloneNode(true);
          clone.querySelectorAll('select').forEach(s => s.remove());
          left = (clone.innerText || '').replace(/\s+/g, ' ').trim() || left;
        }
        const opts = [...sel.options]
          .filter(o => o.value !== '' && !/\bchoose\b|chọn/i.test(o.textContent))
          .map(o => ({ value: o.value, text: o.textContent.trim() }));
        return { index: i + 1, left, options: opts, selectedValue: sel.value };
      });
      return { title, options: [], questionType: 'matching', canvasType: 'moodle_match', matches, hasImages, imageSrcs, imageAlts };
    }

    // ── Fill-in (shortanswer/numerical): input text trong .answer ──
    const textInput = item.querySelector('.answer input[type="text"], .answer input:not([type]), input.form-control');
    if (textInput && !item.querySelector('.answer input[type="radio"], .answer input[type="checkbox"]')) {
      const submitted = textInput.value?.trim() || '';
      const options = submitted ? [{ index: 1, text: `Đã điền: ${submitted}`, selected: true }] : [];
      return { title, options, questionType: 'fill_in', canvasType: 'moodle_shortanswer', hasImages, imageSrcs, imageAlts };
    }

    // ── Essay (textarea): chỉ đọc đề, không auto-fill ──
    if (item.querySelector('.answer textarea, textarea.form-control')) {
      return { title, options: [], questionType: 'fill_in', canvasType: 'moodle_essay', hasImages, imageSrcs, imageAlts };
    }

    // ── Multichoice / TrueFalse: radio hoặc checkbox ──
    const inputs = Array.from(item.querySelectorAll('.answer input[type="radio"], .answer input[type="checkbox"]'));
    if (inputs.length > 0) {
      const options = inputs.map((input, i) => {
        // Text đáp án: label[for] hoặc phần tử bọc (Moodle dùng .ml-1 / .answernumber + text)
        let text = '';
        if (input.id) {
          const label = item.querySelector(`label[for="${CSS.escape(input.id)}"]`);
          if (label) text = extractTextWithMath(label);
        }
        if (!text) {
          const wrap = input.closest('div');
          if (wrap) {
            const clone = wrap.cloneNode(true);
            clone.querySelectorAll('input').forEach(n => n.remove());
            text = extractTextWithMath(clone).replace(/^[a-d]\.\s*/i, '').trim();
          }
        }
        return { index: i + 1, text, selected: Boolean(input.checked) };
      }).filter(o => o.text);
      const isMulti = inputs.some(n => n.type === 'checkbox');
      return {
        title, options,
        questionType: isMulti ? 'multiple_answers' : 'multiple_choice',
        canvasType: 'moodle_multichoice',
        hasImages, imageSrcs, imageAlts,
      };
    }

    // Fallback: không nhận diện được — trả đề để AI đọc, coi như fill-in
    return { title, options: [], questionType: 'fill_in', canvasType: 'moodle_unknown', hasImages, imageSrcs, imageAlts };
  }

  // ═══════════════════════════════════════════════════
  // EXTRACT — CANVAS PORTAL
  // ═══════════════════════════════════════════════════
  function extractPortalQuestion(item) {
    // 1. Ưu tiên lấy LaTeX source từ textarea ẩn (chính xác nhất)
    const latexTA = item.querySelector('textarea.textarea_question_text');
    let title = latexTA?.value?.trim() || '';

    // 2. Fallback: lấy text hiển thị từ .question_text
    if (!title) {
      const qtDiv = item.querySelector('.question_text');
      if (qtDiv) {
        // Lấy cả MathJax assistive text (nằm trong .MJX_Assistive_MathML)
        title = extractTextWithMath(qtDiv);
      }
    }

    // 3. Xác định loại câu hỏi
    const qTypeEl = item.querySelector('.question_type');
    const questionType = qTypeEl?.textContent?.trim() || 'unknown';

    // ── Ảnh trong đề (lấy sớm để dùng chung cho mọi nhánh, gồm cả matching) ──
    const imgEls = Array.from(item.querySelectorAll('.question_text img'));
    const imageSrcs = imgEls.map(img => img.src).filter(Boolean);  // absolute URL
    const imageAlts = imgEls.map(img => img.alt || '(hình vẽ)').filter(Boolean);

    // ── Matching question: mỗi mục con là 1 <select class="question_input"> ──
    // ĐẶT TRƯỚC nhánh .answer vì matching cũng dùng .answer cho mỗi dòng.
    const matchSelects = [...item.querySelectorAll('select.question_input')];
    if (questionType === 'matching_question' || matchSelects.length > 0) {
      const matches = matchSelects.map((sel, i) => {
        const labelEl = sel.id ? item.querySelector(`label[for="${CSS.escape(sel.id)}"]`) : null;
        const left = (labelEl?.textContent || `#${i + 1}`).trim();
        const opts = [...sel.options]
          .filter(o => o.value !== '' && !/\bchoose\b|chọn/i.test(o.textContent))
          .map(o => ({ value: o.value, text: o.textContent.trim() }));
        return { index: i + 1, left, options: opts, selectedValue: sel.value };
      });
      return {
        title,
        options: [],
        questionType: 'matching',
        canvasType: questionType,
        matches,
        hasImages: imageSrcs.length > 0,
        imageSrcs,
        imageAlts,
      };
    }

    // 4. Lấy đáp án theo loại
    let options = [];
    let isFillin = false;

    const answerEls = item.querySelectorAll('.answer');
    
    // Nếu có class .answer và không phải dạng điền khuyết
    if (answerEls.length > 0 && questionType !== 'numerical_question' && questionType !== 'short_answer_question') {
      // Trắc nghiệm (có thể là lúc đang làm hoặc đang xem lại bài)
      options = Array.from(answerEls).map((ans, i) => {
        const textEl = ans.querySelector('.answer_text');
        const labelEl = ans.querySelector('.answer_label');
        const htmlEl = ans.querySelector('.answer_html');

        const parseText = (el) => {
          let t = extractTextWithMath(el);
          return t === 'No answer text provided.' ? '' : t;
        };

        let text = parseText(htmlEl) || parseText(textEl) || parseText(labelEl) || '';
        
        if (!text) {
          // Fallback: lấy text trực tiếp từ thẻ .answer, loại bỏ text thừa trong chế độ review
          text = extractTextWithMath(ans);
          text = text.replace(/Correct Answer/ig, '').replace(/You Answered/ig, '').trim();
          if (text === 'No answer text provided.') text = '';
        }

        // Cứu cánh cuối cùng: nếu text vẫn rỗng do Canvas dùng class ẩn (display:none)
        if (!text && ans.textContent) {
          text = ans.textContent.replace(/Correct Answer/ig, '').replace(/You Answered/ig, '').trim();
          if (text === 'No answer text provided.') text = '';
        }

        const input = ans.querySelector('input[type="radio"], input[type="checkbox"]');
        const isSelected = input ? Boolean(input.checked) : ans.classList.contains('selected_answer');
        
        return { index: i + 1, text, selected: isSelected };
      }).filter(o => o.text);

    } else if (
      questionType === 'numerical_question' ||
      questionType === 'short_answer_question' ||
      item.querySelector('input.question_input')
    ) {
      // Fill-in answer — lấy giá trị đã nhập (nếu có)
      isFillin = true;
      const inputEl = item.querySelector('input.question_input');
      const submitted = inputEl?.value?.trim() || '';
      options = submitted ? [{ index: 1, text: `Đã điền: ${submitted}`, selected: true }] : [];

    } else if (questionType === 'file_upload_question') {
      isFillin = true;
      options = [{ index: 1, text: '[Câu hỏi yêu cầu nộp file]', selected: false }];
    }

    // Câu chọn-nhiều (checkbox): cần trả về nhiều đáp án đúng
    const isMultiAnswer = canvasType_isMultiAnswer(questionType, item);
    const resolvedType = isFillin
      ? 'fill_in'
      : (isMultiAnswer ? 'multiple_answers' : 'multiple_choice');

    return {
      title,
      options,
      questionType: resolvedType,
      canvasType: questionType,
      hasImages: imageSrcs.length > 0,
      imageSrcs,
      imageAlts,
    };
  }

  /** Xác định câu chọn-nhiều: theo canvasType hoặc khi DOM có nhiều checkbox. */
  function canvasType_isMultiAnswer(questionType, item) {
    if (questionType === 'multiple_answers_question') return true;
    const checkboxes = item.querySelectorAll('.answer input[type="checkbox"]');
    return checkboxes.length > 0;
  }

  /**
   * Trích xuất text kết hợp MathJax 2 & 3.
   *
   * MathJax 2 (Canvas cũ): dùng script[type="math/tex"] và script[type="math/tex; mode=display"]
   * MathJax 3 (Canvas mới): dùng mjx-container với thuộc tính math="..." hoặc annotation
   *
   * Output: text thô với công thức được bọc trong $...$ / $$$...$$$
   * để AI có thể đọc và renderMarkdown() hiển thị đẹp.
   */
  function extractTextWithMath(el) {
    if (!el) return '';
    const clone = el.cloneNode(true);

    // ── MathJax 2: display math (block) ──
    clone.querySelectorAll('script[type="math/tex; mode=display"]').forEach(script => {
      const span = document.createElement('span');
      span.textContent = ` $$${script.textContent.trim()}$$ `;
      script.parentNode?.insertBefore(span, script);
    });

    // ── MathJax 2: inline math ──
    clone.querySelectorAll('script[type="math/tex"]').forEach(script => {
      const span = document.createElement('span');
      span.textContent = `$${script.textContent.trim()}$`;
      script.parentNode?.insertBefore(span, script);
    });

    // ── MathJax 3: mjx-container có thuộc tính math="..." ──
    clone.querySelectorAll('mjx-container[math]').forEach(container => {
      const latex = container.getAttribute('math') || '';
      const isDisplay = container.getAttribute('display') === 'true';
      const span = document.createElement('span');
      span.textContent = isDisplay ? ` $$${latex}$$ ` : `$${latex}$`;
      container.parentNode?.insertBefore(span, container);
    });

    // ── MathJax 3: lấy LaTeX từ annotation bên trong nếu không có thuộc tính math ──
    clone.querySelectorAll('mjx-container:not([math]) annotation[encoding="application/x-tex"]').forEach(ann => {
      const latex = ann.textContent.trim();
      const container = ann.closest('mjx-container');
      if (container && latex) {
        const isDisplay = container.getAttribute('display') === 'true';
        const span = document.createElement('span');
        span.textContent = isDisplay ? ` $$${latex}$$ ` : `$${latex}$`;
        container.parentNode?.insertBefore(span, container);
      }
    });

    // ── Image equations (Canvas) ──
    clone.querySelectorAll('img').forEach(img => {
      const span = document.createElement('span');
      if (img.classList.contains('equation_image')) {
        let latex = img.getAttribute('data-mathml') || img.alt || '';
        // Đôi khi Canvas bọc sẵn $$ hoặc \[ \] trong alt, ta làm sạch qua
        latex = latex.replace(/^\$\$?|\\\[|\\\]|\$\$?$/g, '').trim();
        span.textContent = ` $${latex}$ `;
      } else {
        span.textContent = img.alt ? ` [Ảnh: ${img.alt}] ` : ' [Ảnh] ';
      }
      img.parentNode?.insertBefore(span, img);
      img.remove();
    });

    // ── Xóa tất cả element MathJax render và các phần tử ẩn ──
    clone.querySelectorAll([
      '.MathJax_SVG', '.MathJax_Preview', '.MJX_Assistive_MathML',
      '.MathJax', '[id^="MathJax"]',
      'mjx-container', 'math',          // MathML/MathJax3 leftovers
      '.screenreader-only', '.sr-only', '.visually-hidden', '.hidden-readable',
      '[style*="display: none"]', '[style*="display:none"]'
    ].join(', ')).forEach(e => e.remove());

    // Dùng textContent thay vì innerText để bắt được cả text bị display:none
    const finalTxt = clone.innerText?.trim() || clone.textContent || '';
    return finalTxt.replace(/\s+/g, ' ').trim();
  }

  // ═══════════════════════════════════════════════════
  // VISION: Fetch image → base64 (dùng cookie phiên đăng nhập)
  // ═══════════════════════════════════════════════════
  /**
   * Fetch ảnh qua background.js để bypass CORS.
   * Content script bị chặn bởi CORS khi dùng credentials:'include' với CDN trả về wildcard.
   * Background script không bị giới hạn này.
   */
  async function fetchImageBase64(url) {
    return new Promise((resolve) => {
      chrome.runtime.sendMessage({ type: 'FETCH_IMAGE_BASE64', url }, (response) => {
        if (chrome.runtime.lastError) {
          console.error('[HoangDZ] Background error:', chrome.runtime.lastError.message);
          resolve(null);
          return;
        }
        const base64 = response?.base64 || null;
        if (!base64) {
          console.error('[HoangDZ] Background không lấy được ảnh:', response?.error);
        }
        resolve(base64);
      });
    });
  }

  // ═══════════════════════════════════════════════════
  // RENDER KẾT QUẢ
  // ═══════════════════════════════════════════════════

  // ───────────────────────────────────────────────────
  // MATH RENDERING (KATEX)
  // ───────────────────────────────────────────────────

  /**
   * Tách text thành mảng segment: {type: 'block'|'inline'|'text', content: string}
   * Ưu tiên $$...$$ (block) trước $...$ (inline).
   */
  function splitByMath(text) {
    const segments = [];
    // Inline $...$ phải bám sát: không cho whitespace ngay sau $ mở hoặc trước $ đóng.
    // Việc này tránh nhầm các đoạn như "$5 and $10" (kiểu USD) thành công thức toán.
    const regex = /\$\$([\s\S]+?)\$\$|\$(?!\s)([^\n$]+?)(?<!\s)\$/g;
    let lastIndex = 0;
    let match;
    while ((match = regex.exec(text)) !== null) {
      if (match.index > lastIndex) {
        segments.push({ type: 'text', content: text.slice(lastIndex, match.index) });
      }
      if (match[1] !== undefined) {
        segments.push({ type: 'block', content: match[1].trim() });
      } else {
        segments.push({ type: 'inline', content: match[2].trim() });
      }
      lastIndex = match.index + match[0].length;
    }
    if (lastIndex < text.length) {
      segments.push({ type: 'text', content: text.slice(lastIndex) });
    }
    return segments;
  }

  /** Markdown đơn giản cho phần text (không có LaTeX) */
  function applyTextMarkdown(text) {
    let html = escapeHtml(text);
    html = html.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    html = html.replace(/\*(.+?)\*/g, '<em>$1</em>');
    html = html.replace(/`([^`]+)`/g, '<code class="hoangdz-code">$1</code>');
    html = html.replace(/\n/g, '<br>');
    return html;
  }

  /**
   * Render markdown + LaTeX bằng KaTeX cục bộ.
   */
  function renderMarkdown(text) {
    if (!text) return '';
    const parts = splitByMath(text);
    return parts.map(seg => {
      if (seg.type === 'block') {
        try {
          const html = katex.renderToString(seg.content, { displayMode: true, throwOnError: false });
          return `<div class="hoangdz-katex-block" style="overflow-x:auto; margin: 8px 0;">${html}</div>`;
        } catch (e) {
          return `<div class="hoangdz-katex-block"><span class="hoangdz-latex-block">${escapeHtml(seg.content)}</span></div>`;
        }
      }
      if (seg.type === 'inline') {
        try {
          const html = katex.renderToString(seg.content, { displayMode: false, throwOnError: false });
          return `<span class="hoangdz-katex-inline" style="margin: 0 2px;">${html}</span>`;
        } catch (e) {
          return `<code class="hoangdz-latex-inline">${escapeHtml(seg.content)}</code>`;
        }
      }
      return applyTextMarkdown(seg.content);
    }).join('');
  }

  /**
   * Hiển thị kết quả. Nhận full response từ background:
   * { data, fromCache, model, standard, usage:{inTokens,outTokens} }.
   */
  function showResult(container, response) {
    container.textContent = '';
    const data = response?.data || {};
    const mode = currentMode;
    const fromCache = response?.fromCache === true;
    const dualVoting = data.dualVoting;
    const isConflict = Boolean(dualVoting?.enabled && !dualVoting?.agreement);

    // ── GẮN CHẤM SIÊU NHỎ TRÊN OPTION (MICRO-DOT) ──
    const qItem = container.closest(currentSelectors.questionItem);
    if (qItem) {
      // Xóa các chấm cũ trên câu này
      qItem.querySelectorAll('.hoangdz-micro-dot').forEach(d => d.remove());

      const getAnswerOptions = () => {
        if (mode === 'vnu') {
          const inputs = Array.from(qItem.querySelectorAll('.answer input[type="radio"], .answer input[type="checkbox"]'));
          if (inputs.length > 0) {
            return inputs.map(inp => {
              if (inp.id) {
                const lbl = qItem.querySelector('label[for="' + inp.id + '"]');
                if (lbl) return lbl;
              }
              return inp.closest('label') || inp.parentElement || inp;
            });
          }
          return Array.from(qItem.querySelectorAll('.answer > div, .answer .r0, .answer .r1'));
        }
        return Array.from(qItem.querySelectorAll('.answer'));
      };

      const attachDot = (target, dot) => {
        if (!target) return;
        const targetEl = target.querySelector?.('.answer_text') || target.querySelector?.('label') || target;
        targetEl.appendChild(dot);
      };

      const answers = getAnswerOptions();
      if (answers.length > 0) {
        if (dualVoting?.enabled && !dualVoting.agreement) {
          // LỆCH ĐÁP ÁN: Gắn chấm cam trên cả đáp án của Model 1 và Model 2
          const idx1 = dualVoting.model1?.data?.correct_index;
          const idx2 = dualVoting.model2?.data?.correct_index;
          if (idx1 && answers[idx1 - 1]) {
            const dot1 = document.createElement('span');
            dot1.className = 'hoangdz-micro-dot hoangdz-dot-conflict';
            dot1.title = '[Model 1: ' + dualVoting.model1.name + ']: ' + dualVoting.model1.answer;
            attachDot(answers[idx1 - 1], dot1);
          }
          if (idx2 && answers[idx2 - 1] && idx2 !== idx1) {
            const dot2 = document.createElement('span');
            dot2.className = 'hoangdz-micro-dot hoangdz-dot-conflict';
            dot2.title = '[Model 2: ' + dualVoting.model2.name + ']: ' + dualVoting.model2.answer;
            attachDot(answers[idx2 - 1], dot2);
          }
        } else if (data.correct_index && answers[data.correct_index - 1]) {
          // ĐỒNG THUẬN HOẶC SINGLE MODEL: Gắn chấm xanh trên đáp án đúng
          const target = answers[data.correct_index - 1];
          const dot = document.createElement('span');
          dot.className = 'hoangdz-micro-dot';
          let titleText = 'AI: Đáp án đúng';
          if (dualVoting?.enabled && dualVoting.agreement) {
            titleText = '✓ 2/2 Model đồng thuận (100%): ' + dualVoting.model1.name + ' & ' + dualVoting.model2.name;
          } else if (typeof data.confidence === 'number') {
            titleText += ' (' + Math.round(data.confidence * 100) + '%)';
          }
          if (data.explanation) titleText += '\n' + data.explanation;
          dot.title = titleText.trim();
          attachDot(target, dot);
        }
      }
    }

    // ── NẾU BẬT MICRO-DOT VÀ KHÔNG BỊ CONFLICT THÌ ẨN HOÀN TOÀN KHUNG KẾT QUẢ BÊN DƯỚI ──
    if (microDotMode && !isConflict) {
      container.style.display = 'none';
      container.classList.add('hoangdz-micro-mode');
      return;
    } else {
      container.style.display = '';
      container.classList.remove('hoangdz-micro-mode');
    }

    // ── NẾU CÓ CONFLICT GIỮA 2 MODEL: HIỂN THỊ HỘP CẢNH BÁO BÔI MÀU NỔI BẬT ──
    if (isConflict) {
      const conflictBox = document.createElement('div');
      conflictBox.className = 'hoangdz-conflict-box';
      conflictBox.innerHTML = `
        <div class="hoangdz-conflict-header">
          <span class="hoangdz-conflict-icon">⚠️</span>
          <span><b>CẢNH BÁO: 2 MODEL LỆCH ĐÁP ÁN!</b></span>
        </div>
        <div class="hoangdz-conflict-body">
          <div class="hoangdz-conflict-item m1">
            <span class="hoangdz-model-tag">${escapeHtml(dualVoting.model1.name)}:</span>
            <span class="hoangdz-model-ans">${escapeHtml(dualVoting.model1.answer)}</span>
          </div>
          <div class="hoangdz-conflict-item m2">
            <span class="hoangdz-model-tag">${escapeHtml(dualVoting.model2.name)}:</span>
            <span class="hoangdz-model-ans">${escapeHtml(dualVoting.model2.answer)}</span>
          </div>
        </div>
        <div class="hoangdz-conflict-hint">Hãy tự kiểm tra lại câu này trước khi chọn để tránh mất điểm!</div>
      `;
      container.appendChild(conflictBox);
      return;
    }

    // ── NẾU DUAL-MODEL ĐỒNG THUẬN 100% (Ở NORMAL MODE) ──
    if (dualVoting?.enabled && dualVoting.agreement) {
      const dualBadge = document.createElement('div');
      dualBadge.className = 'hoangdz-dual-agreed-badge';
      dualBadge.innerHTML = `
        <span class="hoangdz-check-icon">✓</span>
        <span><b>2/2 Model đồng thuận (100% tin cậy)</b> · <small>${escapeHtml(dualVoting.model1.name)} & ${escapeHtml(dualVoting.model2.name)}</small></span>
      `;
      container.appendChild(dualBadge);
    }

    // ── Cache badge ──
    if (fromCache) {
      const badge = document.createElement('span');
      badge.className = 'hoangdz-cache-badge';
      badge.textContent = 'Từ cache';
      container.appendChild(badge);
    }

    if (mode === 'portal' && data.questionType === 'matching') {
      const wrap = document.createElement('div');
      wrap.className = 'hoangdz-ai-answer';
      const rows = Array.isArray(data.matches) ? data.matches : [];
      const rowsHtml = rows.map(m => {
        const left = escapeHtml(String(m.left || ''));
        const ans = richFormat ? renderMarkdown(String(m.answer || '')) : escapeHtml(String(m.answer || ''));
        return `<div>${left} → <span class="hoangdz-answer-value">${ans}</span></div>`;
      }).join('');
      wrap.innerHTML = `<b>Đáp án ghép nối:</b>${rowsHtml || ' (không có)'}`;
      container.appendChild(wrap);
    } else if (data.questionType === 'multiple_answers') {
      const ansEl = document.createElement('p');
      ansEl.className = 'hoangdz-ai-answer';
      const indices = Array.isArray(data.correct_indices) ? data.correct_indices : [];
      const texts = Array.isArray(data.correct_texts) ? data.correct_texts : [];
      const itemsHtml = indices.map((idx, i) => {
        const t = texts[i] || '';
        const textPart = richFormat ? renderMarkdown(t) : escapeHtml(t);
        return `<span class="hoangdz-answer-value">${escapeHtml(String(idx))}. ${textPart}</span>`;
      }).join(' ');
      ansEl.innerHTML = `<b>Đáp án đúng (chọn nhiều):</b> ${itemsHtml || '(không có)'}`;
      container.appendChild(ansEl);
    } else if (data.questionType === 'fill_in') {
      const ansEl = document.createElement('p');
      ansEl.className = 'hoangdz-ai-answer';
      const textPart = richFormat
        ? renderMarkdown(String(data.answer || data.correct_text || ''))
        : escapeHtml(String(data.answer || data.correct_text || ''));
      ansEl.innerHTML = `<b>Đáp án:</b> <span class="hoangdz-answer-value">${textPart}</span>`;
      container.appendChild(ansEl);
    } else {
      const ansEl = document.createElement('p');
      ansEl.className = 'hoangdz-ai-answer';
      const indexPart = escapeHtml(String(data.correct_index || '') + '. ');
      const textPart = richFormat
        ? renderMarkdown(data.correct_text || '')
        : escapeHtml(data.correct_text || '');
      ansEl.innerHTML = `<b>Đáp án đúng:</b> <span class="hoangdz-answer-value">${indexPart}${textPart}</span>`;
      container.appendChild(ansEl);
    }

    const expEl = document.createElement('p');
    expEl.className = 'hoangdz-ai-explanation';
    if (richFormat) {
      expEl.innerHTML = `<b>Giải thích:</b><br>${renderMarkdown(data.explanation || '')}`;
    } else {
      expEl.innerHTML = `<b>Giải thích:</b> ${escapeHtml(data.explanation || '')}`;
    }
    container.appendChild(expEl);

    if (typeof data.confidence === 'number') {
      const pct = Math.round(data.confidence * 100);
      const confEl = document.createElement('p');
      confEl.className = 'hoangdz-ai-confidence';
      const color = pct >= 80 ? '#16a34a' : pct >= 50 ? '#d97706' : '#dc2626';
      confEl.innerHTML = `Độ chắc chắn: <span style="color:${color};font-weight:700">${pct}%</span>`;
      container.appendChild(confEl);
    }

    // ── Dòng token nhỏ: model · in X · out Y ──
    const tokEl = document.createElement('p');
    tokEl.className = 'hoangdz-tok';
    if (fromCache) {
      tokEl.textContent = 'Từ cache · 0 token';
    } else {
      const modelShort = String(response?.model || '').split('/').pop() || 'AI';
      const inT = response?.usage?.inTokens || 0;
      const outT = response?.usage?.outTokens || 0;
      tokEl.textContent = `${modelShort} · in ${inT.toLocaleString('en-US')} · out ${outT.toLocaleString('en-US')}`;
    }
    container.appendChild(tokEl);
  }

  function showError(container, message, onRetry) {
    container.textContent = '';
    container.classList.add('hoangdz-ai-error');
    const box = document.createElement('div');
    box.className = 'hoangdz-err-box';
    box.setAttribute('role', 'alert');
    const msg = document.createElement('span');
    msg.textContent = 'Lỗi: ' + message;
    box.appendChild(msg);
    if (typeof onRetry === 'function') {
      const retryBtn = document.createElement('button');
      retryBtn.type = 'button';
      retryBtn.className = 'hoangdz-retry-btn';
      retryBtn.setAttribute('aria-label', 'Thử lại câu này');
      retryBtn.innerHTML = `${svgIcon('retry')}<span>Thử lại</span>`;
      retryBtn.addEventListener('click', onRetry);
      box.appendChild(retryBtn);
    }
    container.appendChild(box);
  }

  // ═══════════════════════════════════════════════════
  // AUTO-FILL ANSWER
  // ═══════════════════════════════════════════════════
  function autoFillAnswer(item, data, mode) {
    if (!data) return;

    // Không tự động tick nếu 2 model đang lệch đáp án (để bảo vệ điểm thi)
    if (data.dualVoting?.enabled && !data.dualVoting.agreement) {
      console.warn('[HoangDZ] 2 Model lệch đáp án — bỏ qua auto-fill để bạn tự quyết định.');
      return;
    }

    // Hàm hỗ trợ điền giá trị cho các form có thể dùng React/Vue
    const setInputValue = (input, value) => {
      input.focus(); // Focus vào ô trước

      const nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value")?.set;
      if (nativeInputValueSetter) {
        nativeInputValueSetter.call(input, value);
      } else {
        input.value = value;
      }

      input.dispatchEvent(new Event('input', { bubbles: true }));
      input.dispatchEvent(new Event('change', { bubbles: true }));
      input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'Enter' }));

      input.blur(); // Bỏ focus để kích hoạt sự kiện onBlur (nếu có)
    };

    // Hàm hỗ trợ set value cho <select> + bắn event change để Canvas ghi nhận
    const setSelectValue = (sel, value) => {
      const setter = Object.getOwnPropertyDescriptor(window.HTMLSelectElement.prototype, 'value')?.set;
      if (setter) setter.call(sel, value);
      else sel.value = value;
      sel.dispatchEvent(new Event('input', { bubbles: true }));
      sel.dispatchEvent(new Event('change', { bubbles: true }));
    };

    // Portal mode
    if (mode === 'portal') {
      if (data.questionType === 'matching' && Array.isArray(data.matches)) {
        const selects = item.querySelectorAll('select.question_input');
        data.matches.forEach((m, i) => {
          const sel = selects[i];
          if (!sel) return;
          let value = m.value || '';
          if (!value && m.answer) {
            // Tìm option có text khớp answer
            const ans = String(m.answer).replace(/[*`]/g, '').trim().toLowerCase();
            const opt = [...sel.options].find(o => {
              const t = o.textContent.trim().toLowerCase();
              return t && (t === ans || t.includes(ans) || ans.includes(t));
            });
            if (opt) value = opt.value;
          }
          if (value) {
            setSelectValue(sel, value);
          } else {
            console.warn('[HoangDZ] Matching: không tìm được option cho', m);
          }
        });
      } else if (data.questionType === 'fill_in' && data.answer !== undefined && data.answer !== '') {
        const input = item.querySelector('input.question_input, input[type="text"].numerical_question_input');
        if (input) {
          // Xóa các ký tự markdown dư thừa do AI có thể sinh ra (**6.0000** -> 6.0000)
          let cleanAns = String(data.answer).replace(/[*$`]/g, '').trim();
          setInputValue(input, cleanAns);
        } else {
          console.warn('[HoangDZ] Không tìm thấy ô input điền khuyết trong phần tử:', item);
        }
      } else if (data.questionType === 'multiple_choice' && data.correct_index) {
        const answers = item.querySelectorAll('.answer input[type="radio"], .answer input[type="checkbox"]');
        const target = answers[data.correct_index - 1];
        if (target && !target.checked) {
          target.click(); // Trigger click event
        }
      } else if (data.questionType === 'multiple_answers' && Array.isArray(data.correct_indices)) {
        const answers = item.querySelectorAll('.answer input[type="checkbox"], .answer input[type="radio"]');
        // Bỏ chọn các ô đang tick nhưng KHÔNG nằm trong đáp án đúng
        answers.forEach((inp, i) => {
          const shouldCheck = data.correct_indices.includes(i + 1);
          if (shouldCheck && !inp.checked) inp.click();
          else if (!shouldCheck && inp.checked) inp.click();
        });
      }
    }
    
    // LMS mode
    if (mode === 'lms') {
      if (data.questionType === 'fill_in' && data.answer !== undefined && data.answer !== '') {
        const input = item.querySelector('input[type="text"], input.form-control');
        if (input) {
          let cleanAns = String(data.answer).replace(/[*$`]/g, '').trim();
          setInputValue(input, cleanAns);
        }
      } else if (data.questionType === 'multiple_choice' && data.correct_index) {
        const answers = item.querySelectorAll(SELECTORS.lms.option + ' input');
        const target = answers[data.correct_index - 1];
        if (target && !target.checked) {
          target.click();
        }
      }
    }

    // VNU Moodle mode (lms.vnu.edu.vn) — quiz attempt: .que > .qtext + .answer
    if (mode === 'vnu') {
      if (data.questionType === 'matching' && Array.isArray(data.matches)) {
        const selects = item.querySelectorAll('.answer select, select.custom-select, select.form-control');
        data.matches.forEach((m, i) => {
          const sel = selects[i];
          if (!sel) return;
          let value = m.value || '';
          if (!value && m.answer) {
            const ans = String(m.answer).replace(/[*`]/g, '').trim().toLowerCase();
            const opt = [...sel.options].find(o => {
              const t = o.textContent.trim().toLowerCase();
              return t && (t === ans || t.includes(ans) || ans.includes(t));
            });
            if (opt) value = opt.value;
          }
          if (value) setSelectValue(sel, value);
          else console.warn('[HoangDZ] Matching VNU: không tìm được option cho', m);
        });
      } else if (data.questionType === 'fill_in' && data.answer !== undefined && data.answer !== '') {
        // Essay (textarea) → không fill; chỉ fill shortanswer/numerical (input text)
        const input = item.querySelector('.answer input[type="text"], .answer input:not([type]), input.form-control');
        if (input) {
          const cleanAns = String(data.answer).replace(/[*$`]/g, '').trim();
          setInputValue(input, cleanAns);
        }
      } else if (data.questionType === 'multiple_choice' && data.correct_index) {
        const answers = item.querySelectorAll('.answer input[type="radio"], .answer input[type="checkbox"]');
        const target = answers[data.correct_index - 1];
        if (target && !target.checked) target.click();
      } else if (data.questionType === 'multiple_answers' && Array.isArray(data.correct_indices)) {
        const answers = item.querySelectorAll('.answer input[type="checkbox"], .answer input[type="radio"]');
        answers.forEach((inp, i) => {
          const shouldCheck = data.correct_indices.includes(i + 1);
          if (shouldCheck && !inp.checked) inp.click();
          else if (!shouldCheck && inp.checked) inp.click();
        });
      }
    }
  }

  // ═══════════════════════════════════════════════════
  // FLOATING CHAT
  // ═══════════════════════════════════════════════════
  function createFloatingChat() {
    if (document.getElementById('hoangdz-ai-chat-wrapper')) return;

    const wrapper = document.createElement('div');
    wrapper.id = 'hoangdz-ai-chat-wrapper';

    const box = document.createElement('div');
    box.id = 'hoangdz-ai-chat-box';
    box.className = 'hoangdz-hidden';
    box.setAttribute('role', 'dialog');
    box.setAttribute('aria-label', 'Khung chat AI');

    // ── Header (draggable) ──
    const header = document.createElement('div');
    header.id = 'hoangdz-ai-chat-header';
    header.innerHTML = `
      <span class="hoangdz-chat-title">AI Chat</span>
      <button id="hoangdz-ai-chat-clear-btn" class="hoangdz-chat-hbtn" title="Xóa lịch sử chat" aria-label="Xóa lịch sử chat">${svgIcon('trash')}</button>
      <button id="hoangdz-ai-chat-close-btn" class="hoangdz-chat-hbtn" title="Đóng" aria-label="Đóng khung chat">${svgIcon('x')}</button>
    `;

    // ── Message area ──
    const msgArea = document.createElement('div');
    msgArea.id = 'hoangdz-ai-chat-content';
    msgArea.setAttribute('aria-live', 'polite');

    // ── Empty state ──
    const emptyState = document.createElement('div');
    emptyState.className = 'hoangdz-chat-empty';
    emptyState.innerHTML = '<p>Chào bạn! Hỏi tôi bất cứ điều gì về bài học.</p><p class="hoangdz-chat-empty-hint">Mẹo: dán ảnh (Ctrl+V) hoặc bấm nút đính kèm để hỏi kèm hình.</p>';
    msgArea.appendChild(emptyState);

    // ── Inline confirm xóa history (thay confirm() đồng bộ) ──
    const confirmRow = document.createElement('div');
    confirmRow.className = 'hoangdz-chat-confirm hoangdz-hidden';
    confirmRow.innerHTML = '<span>Xóa toàn bộ lịch sử chat?</span>';
    const confirmOk = document.createElement('button');
    confirmOk.type = 'button';
    confirmOk.className = 'hoangdz-chat-confirm-ok';
    confirmOk.textContent = 'Xóa';
    const confirmCancel = document.createElement('button');
    confirmCancel.type = 'button';
    confirmCancel.className = 'hoangdz-chat-confirm-cancel';
    confirmCancel.textContent = 'Hủy';
    confirmRow.append(confirmOk, confirmCancel);

    // ── Image preview strip ──
    const imgPreview = document.createElement('div');
    imgPreview.id = 'hoangdz-ai-chat-img-preview';
    imgPreview.style.display = 'none';

    // ── Input row ──
    const inputArea = document.createElement('div');
    inputArea.id = 'hoangdz-ai-chat-input-area';

    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    fileInput.multiple = true;
    fileInput.style.display = 'none';

    const attachBtn = document.createElement('button');
    attachBtn.id = 'hoangdz-ai-chat-attach-btn';
    attachBtn.type = 'button';
    attachBtn.title = 'Đính kèm ảnh';
    attachBtn.setAttribute('aria-label', 'Đính kèm ảnh');
    attachBtn.innerHTML = svgIcon('clip');

    const textInput = document.createElement('input');
    textInput.id = 'hoangdz-ai-chat-input';
    textInput.type = 'text';
    textInput.placeholder = 'Nhập tin nhắn... (Enter)';
    textInput.setAttribute('aria-label', 'Nhập tin nhắn chat');

    const sendBtn = document.createElement('button');
    sendBtn.id = 'hoangdz-ai-chat-send-btn';
    sendBtn.type = 'button';
    sendBtn.title = 'Gửi';
    sendBtn.setAttribute('aria-label', 'Gửi tin nhắn');
    sendBtn.innerHTML = svgIcon('send');

    inputArea.append(fileInput, attachBtn, textInput, sendBtn);

    // ── Resize handles: n (top), w (left), nw (top-left corner) ──
    ['n', 'w', 'nw'].forEach(dir => {
      const h = document.createElement('div');
      h.className = `hoangdz-resize-handle hoangdz-resize-${dir}`;
      box.appendChild(h);
    });

    // ── Toggle button ──
    const toggle = document.createElement('button');
    toggle.id = 'hoangdz-ai-chat-toggle';
    toggle.type = 'button';
    toggle.title = 'Mở chat AI';
    toggle.setAttribute('aria-label', 'Mở hoặc đóng khung chat AI');
    toggle.innerHTML = svgIcon('chat');

    box.append(header, msgArea, confirmRow, imgPreview, inputArea);
    wrapper.append(box, toggle);
    document.body.appendChild(wrapper);

    // ── State: selected images ──
    let pendingImgs = []; // [{dataUrl, name}]

    // ── Attach ──
    attachBtn.addEventListener('click', () => fileInput.click());
    fileInput.addEventListener('change', async () => {
      for (const f of Array.from(fileInput.files)) {
        const dataUrl = await readFileAsBase64(f);
        if (dataUrl) pendingImgs.push({ dataUrl, name: f.name });
      }
      fileInput.value = '';
      renderPreviews(imgPreview, pendingImgs);
    });

    // ── Send ──
    const doSend = () => {
      const msg = textInput.value.trim();
      if (!msg && pendingImgs.length === 0) return;
      textInput.value = '';
      const imgs = pendingImgs.map(i => i.dataUrl);
      pendingImgs = [];
      renderPreviews(imgPreview, pendingImgs);
      emptyState.remove();
      appendMsg('Bạn', msg, false, imgs);
      appendMsg('AI', 'Đang trả lời...', true);
      chrome.runtime.sendMessage(
        { type: 'CHAT_CONVERSATION', text: msg, images: imgs },
        (res) => {
          removeLoadingMsg();
          if (chrome.runtime.lastError) { appendMsg('Lỗi', chrome.runtime.lastError.message); return; }
          if (res?.success) appendMsg('AI', res.reply);
          else appendMsg('Lỗi', res?.error || 'Không phản hồi.');
        }
      );
    };
    textInput.addEventListener('keydown', e => { if (e.key === 'Enter') doSend(); });
    sendBtn.addEventListener('click', doSend);

    // ── Paste ảnh bằng Ctrl+V ──
    textInput.addEventListener('paste', async (e) => {
      const items = Array.from(e.clipboardData?.items || []);
      const imageItems = items.filter(it => it.type.startsWith('image/'));
      if (imageItems.length === 0) return; // không có ảnh → paste text bình thường
      e.preventDefault(); // chặn paste text khi có ảnh
      for (const item of imageItems) {
        const file = item.getAsFile();
        if (!file) continue;
        const dataUrl = await readFileAsBase64(file);
        if (dataUrl) pendingImgs.push({ dataUrl, name: 'clipboard.png' });
      }
      renderPreviews(imgPreview, pendingImgs);
    });

    // ── Mở/đóng: focus vào input khi mở, trả focus về toggle khi đóng ──
    const setChatOpen = (open) => {
      box.classList.toggle('hoangdz-hidden', !open);
      if (open) {
        textInput.focus();
      } else {
        toggle.focus();
      }
    };
    const isChatOpen = () => !box.classList.contains('hoangdz-hidden');

    // ── Toggle open/close ──
    toggle.addEventListener('click', () => setChatOpen(!isChatOpen()));

    // ── ESC đóng chat ──
    box.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        confirmRow.classList.add('hoangdz-hidden');
        setChatOpen(false);
      }
    });

    // ── Close button ──
    header.querySelector('#hoangdz-ai-chat-close-btn')?.addEventListener('click', (e) => {
      e.stopPropagation();
      setChatOpen(false);
    });

    // ── Clear chat history (inline confirm 2 bước) ──
    header.querySelector('#hoangdz-ai-chat-clear-btn')?.addEventListener('click', (e) => {
      e.stopPropagation();
      confirmRow.classList.toggle('hoangdz-hidden');
    });
    confirmCancel.addEventListener('click', (e) => {
      e.stopPropagation();
      confirmRow.classList.add('hoangdz-hidden');
    });
    confirmOk.addEventListener('click', (e) => {
      e.stopPropagation();
      chrome.storage.local.remove('chatHistory');
      msgArea.innerHTML = '';
      msgArea.appendChild(emptyState);
      confirmRow.classList.add('hoangdz-hidden');
      appendMsg('AI', 'Lịch sử đã được xóa. Bắt đầu cuộc trò chuyện mới!');
    });

    // ── Draggable header ──
    makeDraggable(wrapper, header);

    // ── Resizable borders ──
    makeResizable(box);
  }

  // ── Drag wrapper by header ──
  function makeDraggable(wrapper, handle) {
    handle.addEventListener('mousedown', e => {
      if (e.target.tagName === 'BUTTON') return;
      e.preventDefault();
      const startX = e.clientX, startY = e.clientY;
      const cs = window.getComputedStyle(wrapper);
      let r0 = parseInt(cs.right) || 20;
      let b0 = parseInt(cs.bottom) || 20;
      const onMove = e => {
        wrapper.style.right = Math.max(0, r0 - (e.clientX - startX)) + 'px';
        wrapper.style.bottom = Math.max(0, b0 - (e.clientY - startY)) + 'px';
      };
      const onUp = () => {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      };
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  }

  // ── Resize by dragging n / w / nw handles ──
  function makeResizable(box) {
    box.querySelectorAll('.hoangdz-resize-handle').forEach(handle => {
      const dir = handle.className.includes('nw') ? 'nw'
        : handle.className.includes('n') ? 'n' : 'w';
      handle.addEventListener('mousedown', e => {
        e.preventDefault();
        const startX = e.clientX, startY = e.clientY;
        const startW = box.offsetWidth, startH = box.offsetHeight;
        const onMove = e => {
          if (dir === 'w' || dir === 'nw') {
            // dragging left → wider (box anchored to right)
            box.style.width = Math.max(280, startW - (e.clientX - startX)) + 'px';
          }
          if (dir === 'n' || dir === 'nw') {
            // dragging up → taller (box anchored to bottom)
            box.style.height = Math.max(300, startH - (e.clientY - startY)) + 'px';
          }
        };
        const onUp = () => {
          document.removeEventListener('mousemove', onMove);
          document.removeEventListener('mouseup', onUp);
        };
        document.addEventListener('mousemove', onMove);
        document.addEventListener('mouseup', onUp);
      });
    });
  }

  // ── Read file as base64 data URL ──
  function readFileAsBase64(file) {
    return new Promise(resolve => {
      const r = new FileReader();
      r.onloadend = () => resolve(r.result);
      r.onerror = () => resolve(null);
      r.readAsDataURL(file);
    });
  }

  // ── Render image thumbnails in preview strip ──
  function renderPreviews(container, imgs) {
    container.innerHTML = '';
    container.style.display = imgs.length ? 'flex' : 'none';
    imgs.forEach((img, i) => {
      const wrap = document.createElement('div');
      wrap.className = 'hoangdz-img-thumb';
      const el = document.createElement('img');
      el.src = img.dataUrl;
      const rm = document.createElement('button');
      rm.className = 'hoangdz-img-thumb-rm';
      rm.textContent = '×';
      rm.addEventListener('click', () => { imgs.splice(i, 1); renderPreviews(container, imgs); });
      wrap.append(el, rm);
      container.appendChild(wrap);
    });
  }

  function appendMsg(sender, text, loading = false, images = []) {
    const area = document.getElementById('hoangdz-ai-chat-content');
    if (!area) return;
    const row = document.createElement('div');
    row.className = 'hoangdz-ai-chat-msg' + (loading ? ' hoangdz-ai-loading' : '');
    const name = document.createElement('strong');
    name.textContent = sender + ': ';
    const body = document.createElement('span');
    // Render markdown trong chat khi richFormat bật
    if (richFormat && sender === 'AI' && !loading) {
      body.innerHTML = renderMarkdown(text);
    } else {
      body.textContent = text;
    }
    row.append(name, body);
    if (images.length) {
      const strip = document.createElement('div');
      strip.style.cssText = 'display:flex;gap:4px;flex-wrap:wrap;margin-top:4px;';
      images.forEach(src => {
        const img = document.createElement('img');
        img.src = src;
        img.style.cssText = 'width:60px;height:60px;object-fit:cover;border-radius:4px;border:1px solid #d1d5db;';
        strip.appendChild(img);
      });
      row.appendChild(strip);
    }
    area.appendChild(row);
    area.scrollTop = area.scrollHeight;
  }

  function removeLoadingMsg() {
    document.querySelectorAll('.hoangdz-ai-loading').forEach(el => el.remove());
  }

  // ═══════════════════════════════════════════════════
  // UTIL
  // ═══════════════════════════════════════════════════
  function escapeHtml(value) {
    return String(value)
      .replaceAll('&', '&amp;')
      .replaceAll('<', '&lt;')
      .replaceAll('>', '&gt;')
      .replaceAll('"', '&quot;')
      .replaceAll("'", '&#039;');
  }

})();
